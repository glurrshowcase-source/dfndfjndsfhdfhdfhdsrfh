# Zgodność GxLx z dostarczonym zrzutem i MH9

**To nie jest pełny klon MH9.** Dokument obejmuje nazwy czytelne na dostarczonym zrzucie oraz kilka głównych funkcji nowszego MH9. Nie stanowi kompletnego katalogu wszystkich wersji MH9.

„W kodzie” oznacza zaimplementowaną funkcję w skompilowanym modzie, a nie test zachowania w uruchomionej grze. Takiego testu nie wykonano w tym środowisku. „Częściowo” nie oznacza równoważności 1:1. Brakujące funkcje nie są zastąpione pozornie działającymi przełącznikami.

## Aktualizacja wyglądu 1.1.1

Dodano animacje otwierania/zamykania, logo i napis wyłącznie dla otwartego menu, przesłany dźwięk skrótu, ikonę Geode oraz czarny ekran LoadingLayer z czerwonym paskiem rzeczywistego postępu. W ustawieniach Geode pozostał tylko keybind. Istniejący keybind jest zachowany. W 1.1.1 usunięto alternatywne menu Cocos: dostępne jest wyłącznie ImGui, również przy aktualizacji ze starej konfiguracji lub motywu. Zmiany nie rozszerzają zakresu funkcji gameplay z tabel poniżej.

Kod zbudowano dla Windows x64 i sprawdzono animację ImGui poza grą. Dźwięku oraz ładowania w uruchomionym GD jeszcze nie przetestowano.

## Bypass

| Opcja referencyjna | Stan | Gdzie / zakres |
|---|---|---|
| Backup Stars Limit | Brak | Brak obejścia walidacji kopii konta. |
| Basement Key Bypass | Częściowo / zamiennik | Unlock Vaults: klucze i dostęp do skarbców połączone w jednym przełączniku. |
| Challenge Bypass | Brak | Brak osobnego obejścia The Challenge. |
| Character Filter | W kodzie | Bypass → Character Filter Bypass. |
| Demon Gauntlet | Brak | Brak osobnego odblokowania Demon Gauntlet. |
| Gatekeeper Vault | Częściowo / zamiennik | Unlock Vaults; nie odtworzono oddzielnych przełączników każdego skarbca. |
| Guard Vault | Częściowo / zamiennik | Unlock Vaults. |
| Icons | W kodzie | Bypass → Unlock Icons. |
| Keymaster Basement | Częściowo / zamiennik | Unlock Vaults. |
| Keymaster Vault | Częściowo / zamiennik | Unlock Vaults. |
| Main Levels | W kodzie | Bypass → Unlock Main Levels. |
| Potbor Shop | W kodzie | Bypass → Unlock Shops. |
| Scratch Shop | W kodzie | Bypass → Unlock Shops. |
| Shop Items | Częściowo / zamiennik | Unlock Icons udostępnia ikony; nie jest to zakup lub zmiana stanu całego sklepu. |
| Slider Limit | W kodzie | Creator → Slider Limit. |
| Text Length | W kodzie | Bypass → Character Limit Bypass. |
| Treasure Room | W kodzie | Bypass → Unlock Vaults. |

## Cosmetic

| Opcja referencyjna | Stan | Gdzie / zakres |
|---|---|---|
| Accurate Percentage | W kodzie | Level → Accurate Percentage. |
| Coins Show Uncollected | Częściowo / zamiennik | Always Show Coins; podobna funkcja widoczności monet. |
| Force Don’t Enter | W kodzie | Cosmetic → Force Don't Enter. |
| Force Don’t Fade | W kodzie | Cosmetic → Force Don't Fade. |
| Hide Attempts | W kodzie | Cosmetic → Hide Attempts. |
| Hide Pause Button | W kodzie | Cosmetic → Hide Pause Button. |
| Hide Pause Menu | W kodzie | Level → Hide Pause Menu. |
| Inversed Trail | Częściowo / zamiennik | Icons → Inversed Trail; zamiana koloru zwykłej smugi na drugi kolor gracza. |
| Mini Cube Icon | W kodzie | Display → Mini Cube Icon; natywne ustawienie GD. |
| No Death Effect | W kodzie | Player → No Death Effect. |
| No Force Glow | W kodzie | Cosmetic → No Force Glow. |
| No Ghost Trail | W kodzie | Player → No Ghost Trail. |
| No Glow | W kodzie | Level → No Object Glow. |
| No Hide Trigger | W kodzie | Player → No Hide Trigger. |
| No Mirror | W kodzie | Level → No Mirror. |
| No New Best Popup | W kodzie | Cosmetic → No New Best Popup. |
| No Orb Ring | W kodzie | Icons → No Orb Ring. |
| No Particles | W kodzie | Level → No Particles, z opcjami zwykłych i własnych cząsteczek. |
| No Portal Lightning | W kodzie | Level → No Portal Lightning. |
| No Pulse | W kodzie | Cosmetic → No Pulse; pomija zmianę koloru przez efekty Pulse. |
| No Respawn Flash | W kodzie | Player → No Respawn Flash. |
| No Spider Dash | W kodzie | Player → No Spider Dash. |
| No Wave Pulse | W kodzie | Cosmetic → No Wave Pulse. |
| No Wave Trail | W kodzie | Cosmetic → No Wave Trail. |
| No Wave Trail Behind | W kodzie | Player → No Wave Trail Behind. |
| Practice Pulse | Brak | Brak osobnego przywracania pulsu zależnego od muzyki w practice. |
| Practice User-Coins | W kodzie | Level → Practice Coins. |
| Show Total Attempts | W kodzie | Labels → Total Attempts; globalna liczba prób konta. |
| Solid Wave Trail | W kodzie | Player → Solid Wave Trail. |
| Stable Pulse | Częściowo / zamiennik | Cosmetic → Stable Pulse; stabilizuje rozmiar wave trail, nie wszystkie efekty muzyczne. |
| Stop Triggers on Death | W kodzie | Level → Stop Triggers on Death. |
| Trail Always Off | W kodzie | Player → No Trail. |
| Trail Always On | W kodzie | Player → Always Show Trail. |
| Trail Bug Fix | Częściowo / zamiennik | Legacy Trail jest alternatywnym sposobem rysowania; nie potwierdzono równoważności łatki MH. |
| Wave Trail Bug Fix | Częściowo / zamiennik | Dostępne Wave Trail On Death i Custom Wave Trail; bez potwierdzenia identycznej poprawki MH. |

## Creator

| Opcja referencyjna | Stan | Gdzie / zakres |
|---|---|---|
| Absolute Position | W kodzie | Creator → pola X/Y i Apply absolute position. Pozycja środka zaznaczenia. |
| Absolute Scaling | W kodzie | Creator → Scale X/Y i Apply absolute scale. |
| Anti-Kick | Częściowo / zamiennik | Bypass → Level Kick; nie odwzorowuje każdej dawnej łatki edytora. |
| ColourID Bypass | Brak | Brak usuwania limitów identyfikatorów kolorów. |
| Copy Hack | W kodzie | Creator → Level Copy Bypass. |
| Custom Object Bypass | W kodzie | Creator → Custom Object Bypass. |
| Default Song Bypass | W kodzie | Creator → Default Song Bypass. |
| Editor Extension | Częściowo / zamiennik | Free Scroll usuwa ograniczenie przewijania; nie jest osobną łatką długości poziomu. |
| Free Scroll | W kodzie | Creator → Free Scroll. |
| Group ID Bypass | Brak | Brak usuwania limitów identyfikatorów grup. |
| Hide UI | W kodzie | Creator → Hide UI. |
| Level Edit | W kodzie | Creator → Level Edit. |
| No (C) Mark | W kodzie | Creator → No (C) Mark. |
| No Editor Trail | W kodzie | Creator → No Editor Trail; natywne Hide Player Path. |
| Object Bypass | Brak | Brak osobnej łatki limitu obiektów. |
| Place Over | Brak | Brak osobnego obejścia nakładania obiektów. |
| Playtest Zoom Bypass | Częściowo / zamiennik | Pole Zoom / Playtest Zoom; brak potwierdzenia wszystkich ograniczeń przy zmianie trybu edytora. |
| Rotation Hack (Lags) | Częściowo / zamiennik | Obrót zaznaczenia o podaną liczbę stopni; bez emulacji starej łatki obracającej każdy typ obiektu. |
| Scale Snap Bypass | W kodzie | Dokładne wpisywanie skali w narzędziach GxLx. |
| Smooth Editor Trail | W kodzie | Creator → Smooth Editor Trail. |
| Toolbox Button Bypass | Brak | Brak osobnej zmiany limitu przycisków toolboxa. |
| Verify Hack | W kodzie | Creator → Verify Bypass. |
| Z Order Bypass | W kodzie | Creator → pole Z Order, zakres -32768…32767. |
| Zoom Bypass | Częściowo / zamiennik | Dodatkowe pole zoomu; brak potwierdzenia wszystkich wewnętrznych ograniczeń GD. |

## Level

| Opcja referencyjna | Stan | Gdzie / zakres |
|---|---|---|
| 0% Practice Complete | W kodzie | Level → 0% Practice Completion. |
| Auto Deafen | W kodzie | Universal → Auto Deafen; skrót Windows, domyślnie F13, wymaga konfiguracji Discorda. |
| Auto Low Detail Mode | W kodzie | Level → Auto LDM. |
| Auto Music Sync | Brak | Brak samoczynnej korekcji pozycji muzyki. |
| Auto Pickup Coins | W kodzie | Level → Auto Pickup Coins. |
| Auto Practice Mode | W kodzie | Level → Auto Practice Mode. |
| Auto Song Download | W kodzie | Level → Auto Song Download. |
| Ball Rotation Bug | W kodzie | Player → Ball Rotation Bug. |
| Corrective Music Sync | Brak | Brak osobnej korekcji synchronizacji dźwięku. |
| Everything Hurts | Częściowo / zamiennik | Level → Everything Hurts; kontakt z obiektami przekazanymi do sprawdzania kolizji zabija. |
| Force Block Type | Brak | Brak wymuszenia typu kolizji bloków. |
| Freeze Attempts | W kodzie | Level → Freeze Attempts. |
| Freeze Player | W kodzie | Level → Freeze Player; wstrzymuje aktualizację PlayerObject. |
| Hitbox Multiplier | W kodzie | Level → Hitbox Multiplier, osobno gracz / przeszkody / bryły. |
| Ignore ESC | W kodzie | Level → Ignore ESC. |
| Insta Kill | Częściowo / zamiennik | Player → Auto Kill, z warunkiem procentu lub czasu. |
| Instant Complete | W kodzie | Bypass → Instant Complete. |
| Jump Hack | W kodzie | Player → Jump Hack. |
| No Hitbox | W kodzie | Level → No Hitbox; pomija bryły, zbocza i przeszkody w wykrywaniu kolizji. |
| No Solids | W kodzie | Level → No Solids. |
| No Spikes | W kodzie | Level → No Spikes. |
| Noclip | W kodzie | Player → Noclip, z ustawieniami P1/P2 i licznikami. |
| Pause During Complete | W kodzie | Level → Pause During Complete. |
| Practice Bug Fix | W kodzie | Level → Practice Fix. |
| Practice Music Hack | W kodzie | Bypass → Practice Music Sync. |
| Replay Last Checkpoint | Częściowo / zamiennik | Restart Level w trybie practice; bez osobnego przycisku o tej nazwie. |
| Show Hitboxes | W kodzie | Level → Show Hitboxes. |
| Show Layout | W kodzie | Level → Layout Mode. |
| Show Level Password | W kodzie | Shortcuts → Show Level Password. |
| Smart Start Pos | W kodzie | Level → Smart StartPos. |
| StartPos Lag Bug Fix | Brak | Brak osobnej łatki opóźnienia StartPos. |
| StartPos Switcher | W kodzie | Level → StartPos Switcher. |
| Void Click Bug Fix | Brak | Brak osobnej łatki void click. |

## Universal

| Opcja referencyjna | Stan | Gdzie / zakres |
|---|---|---|
| Allow Low Volume | W kodzie | Bypass → Allow Low Volume. |
| Custom Levels on Launch | Brak | Brak automatycznego otwierania własnych poziomów przy starcie. |
| Fast Alt-Tab | Brak | Brak osobnej łatki; można użyć natywnego trybu borderless GD. |
| Force Visibility | W kodzie | Level → Force Visibility. |
| Free Window Resize | W kodzie | Universal → Free Window Resize; w trybie okienkowym. |
| Lock Cursor | W kodzie | Universal → Lock Cursor. |
| Mute on Unfocus | W kodzie | Universal → Mute on Unfocus; przywraca poprzedni stan master mute. |
| No Rotation | W kodzie | Cosmetic → No Rotation; obrót ikony. |
| No Transition | W kodzie | Universal → Transition Speed ustawione na 0. |
| Safe Mode | W kodzie | Universal → Safe Mode i Auto Safe Mode. |
| Transition Customiser | Częściowo / zamiennik | Transition Speed zmienia czas; nie dodaje pełnej biblioteki animacji MH. |
| Transparent BG | Brak | Brak osobnego przezroczystego tła scen gry. |
| Transparent Lists | W kodzie | Universal → Transparent Lists. |
| Unfocused FPS | W kodzie | Universal → Unfocused FPS; 0 pozostawia dotychczasowy limit. |

## Display / Speedhack

| Opcja referencyjna | Stan | Gdzie / zakres |
|---|---|---|
| FPS Bypass | W kodzie | Universal → FPS Bypass. |
| Smooth Fix | W kodzie | Display → Smooth Fix; ustawienie GD. |
| V-Sync | W kodzie | Universal → Vertical Sync. |
| Force Smooth Fix | W kodzie | Display → Force Smooth Fix; ustawienie GD. |
| Flicker Fix | Brak | Brak osobnej łatki migotania. |
| Low Detail | W kodzie | Display → Low Detail; ustawienie GD. |
| Windowed | W kodzie | Display → Windowed. |
| Resolution / Set | W kodzie | Display → Width / Height / Set Window Size. |
| Screenshot | W kodzie | Display → Screenshot (PNG), zapis sceny gry bez nakładki ImGui. |
| Refresh Textures | Brak | Brak osobnego przycisku przeładowania tekstur. |
| Speedhack Value / Enabled | W kodzie | Universal → Speedhack. |
| Speedhack Audio | W kodzie | Universal → Audio Speed / Sync with Speedhack. |
| Classic Mode | Brak | Brak emulacji starszego trybu speedhack MH. |

## Status

| Opcja referencyjna | Stan | Gdzie / zakres |
|---|---|---|
| Opacity / Scale | W kodzie | Ustawienia poszczególnych etykiet w Labels. |
| Testmode | W kodzie | Labels → Testmode. |
| Cheat Indicator | W kodzie | Labels → Cheat Indicator, wraz z Auto Safe Mode. |
| Message | W kodzie | Labels → Message; tekst można edytować. |
| Show Percentage | W kodzie | Display → Show Percentage lub Labels → Percentage. |
| FPS Counter | W kodzie | Labels → FPS. |
| CPS Counter | W kodzie | Labels → CPS. |
| Noclip Accuracy | W kodzie | Labels → Noclip Accuracy. |
| Noclip Deaths | W kodzie | Labels → Noclip Deaths. |
| Session Time | W kodzie | Labels → Session Time, czas od załadowania modułu. |
| Clock | W kodzie | Labels → Clock. |
| Best Run | W kodzie | Labels → Best Run. |
| Attempts | W kodzie | Labels → Attempt / Total Attempts. |
| Jumps | Częściowo / zamiennik | Labels → Jumps; całkowite skoki konta, nie osobny licznik skoków w próbie. |

## Icons

| Opcja referencyjna | Stan | Gdzie / zakres |
|---|---|---|
| Player 1 / Player 2 | W kodzie | Icons → Player 1 / Player 2; osobne ustawienia. |
| Colour 1 | W kodzie | No Effect / Custom Colour / Rainbow. |
| Colour 2 | W kodzie | No Effect / Custom Colour / Rainbow. |
| Glow | W kodzie | No Effect / Custom Colour / Rainbow. |
| Trail | W kodzie | No Effect / Custom Colour / Rainbow. |
| Particles | W kodzie | No Effect / Custom Colour / Rainbow. |
| Wave | W kodzie | No Effect / Custom Colour / Rainbow. |
| Cycle Speed | W kodzie | Icons → Cycle Speed. |
| Same Dual Colour | W kodzie | P2 używa konfiguracji efektów P1. |
| Icon Randomiser | W kodzie | Losowanie wszystkich 9 typów ikon. Zastosowanie po ponownym wejściu do poziomu. |

## Shortcuts / Interface / Extensions

| Opcja referencyjna | Stan | Gdzie / zakres |
|---|---|---|
| P1 Jump / P2 Jump | Częściowo / zamiennik | Obsługa wejścia i bota; brak odrębnych przycisków skoku na panelu Shortcuts. |
| Options | W kodzie | Shortcuts → Show Options. |
| Restart Level | W kodzie | Shortcuts → Restart Level. |
| Reset Volume | W kodzie | Shortcuts → Reset BG Volume / Reset SFX Volume. |
| Uncomplete Level | W kodzie | Shortcuts → Uncomplete Level. |
| Inject DLL | W kodzie | Shortcuts → Inject DLL, odziedziczone narzędzie Windows. |
| Resources | Częściowo / zamiennik | Brak osobnego skrótu do Resources; folder jest w instalacji GD. |
| AppData | W kodzie | Shortcuts → Save Folder otwiera katalog danych moda. |
| Keybinds | W kodzie | Keybinds i menu pod prawym przyciskiem na obsługiwanych opcjach. |
| Disable in Editor | Brak | Brak jednego globalnego przełącznika wyłączającego wszystkie keybindy w edytorze. |
| Extensions / Find Extensions | Częściowo / zamiennik | Mody Geode; binarne rozszerzenia MH nie są obsługiwane. |
| Search | W kodzie | Interface → Search. |
| Transition Time | W kodzie | Interface → Animation Duration. |
| UI Scale | W kodzie | Interface → UI Scale. |
| Sort Windows | W kodzie | Interface → Stack Windows i opcje układu. |
| Auto Save / Save | W kodzie | Zapis konfiguracji przy zamknięciu menu; profile w Interface. |
| Auto Update | Brak | Brak własnego serwera aktualizacji GxLx. |
| Discord Rich Presence | W kodzie | Universal → Discord RPC. |
| Thread Priority | W kodzie | Universal → Thread Priority. |
| Special Thanks | W kodzie | Pełne podziękowania w README-UPSTREAM.md i ekranie informacji moda. |
| Variables | Brak | Brak edytora surowych zmiennych pamięci MH. |
| Favourites | Brak | Brak edytowalnego panelu przypiętych dowolnych opcji. |

## Dodatkowe główne funkcje reklamowane w MH9

| Opcja referencyjna | Stan | Gdzie / zakres |
|---|---|---|
| Replay / Bot | W kodzie | Bot → nagrywanie, odtwarzanie, zapis i odczyt makr; formaty obsługiwane przez Eclipse/GDR. |
| Frame Extrapolation | Brak | Nie zaimplementowano. Physics/TPS Bypass nie jest zamiennikiem extrapolation. |
| Rulesets / Demonlist | Brak | Brak aktualizowanych zestawów reguł MH9. |

