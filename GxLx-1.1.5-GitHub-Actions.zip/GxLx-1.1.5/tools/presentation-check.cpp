// Functional regression checks for rapid reversal, clipping, and draw limits.
#include <modules/gui/imgui/gxlx-motion.hpp>
#include <cassert>
#include <iostream>

int main() {
    using namespace gxlx::motion;
    Reveal r;
    assert(!r.visible());
    r.target(true);
    r.advance(.2f);
    float before = r.value();
    r.target(false);
    assert(r.value() == before); // changing direction cannot jump the menu
    r.advance(.05f);
    assert(r.value() < before && r.visible());
    before = r.value();
    r.target(true);
    assert(r.value() == before);
    r.advance(2.f);
    assert(r.value() == 1.f && !r.moving());
    for (int slot=0;slot<20;slot++) {
        auto settled = sample(1.f,slot,20,1920,1080);
        assert(std::abs(settled.x) < .001 && std::abs(settled.y) < .001);
        assert(std::abs(settled.rotation) < .001 && std::abs(settled.scale-1) < .001);
        assert(sample(0.f,slot,20,1920,1080).alpha == 0.f);
        for (int frame=0;frame<=120;frame++) {
            auto pose=sample(frame/120.f,slot,20,1920,1080);
            assert(std::isfinite(pose.x) && std::isfinite(pose.y));
            assert(pose.scale > 0 && pose.alpha >= 0 && pose.alpha <= 1);
        }
    }
    r.target(false); r.advance(2.f);
    assert(!r.visible() && !r.moving());

    ImGui::CreateContext();
    auto& io=ImGui::GetIO();io.DisplaySize={800,600};io.IniFilename=nullptr;
    io.BackendFlags|=ImGuiBackendFlags_RendererHasVtxOffset;
    unsigned char* pixels;int width,height;
    io.Fonts->GetTexDataAsRGBA32(&pixels,&width,&height);
    io.Fonts->SetTexID((ImTextureID)1);
    ImGui::NewFrame();
    auto* src=ImGui::GetBackgroundDrawList();
    src->PushClipRect({0,0},{100,100},false);
    src->AddTriangleFilled({-10,-10},{110,-10},{50,110},IM_COL32_WHITE);
    src->PopClipRect();
    auto* dst=ImGui::GetForegroundDrawList();
    relocateDrawList(src,dst,{50,50},{13,22,90,1,1});
    assert(dst->VtxBuffer.Size > 0);
    for(auto const& v:dst->VtxBuffer) {
        // Invert the known 90-degree rotation to check the ORIGINAL clipping region.
        float x=v.pos.y-22, y=100-(v.pos.x-13);
        assert(x>=-.001 && x<=100.001 && y>=-.001 && y<=100.001);
    }
    for(auto const& cmd:src->CmdBuffer) assert(cmd.ElemCount==0);
    ImGui::Render();
    ImGui::DestroyContext();
    std::cout << "PASS: reversal, settling, hidden endpoint, finite poses, transformed clipping\n";
}
