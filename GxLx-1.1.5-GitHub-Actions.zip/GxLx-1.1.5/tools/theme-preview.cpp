// Headless visual smoke test for GxLx native ImGui decorations. EPL-2.0.
#include <imgui.h>
#include "modules/gui/imgui/gxlx-style.hpp"
#include "modules/gui/imgui/gxlx-motion.hpp"
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <cmath>
#include <iostream>
struct Panel { std::string title; std::vector<std::string> rows; float x,y,h; };
float edge(ImVec2 a,ImVec2 b,float x,float y){return (x-a.x)*(b.y-a.y)-(y-a.y)*(b.x-a.x);}
int main(int argc,char**argv){
 std::vector<unsigned char> logoPixels(1254*1254*4);
 if(argc>3) {std::ifstream logoFile(argv[3],std::ios::binary);logoFile.read((char*)logoPixels.data(),logoPixels.size());}
 const float reveal=argc>4?std::stof(argv[4]):1.f;
 const bool menuOpen=argc>5?std::stoi(argv[5])!=0:true;
 const int W=1600,H=1000; ImGui::CreateContext(); auto& io=ImGui::GetIO();io.IniFilename=nullptr;io.DisplaySize={(float)W,(float)H};io.DeltaTime=1.f/60;io.BackendFlags|=ImGuiBackendFlags_RendererHasVtxOffset;
 io.Fonts->AddFontFromFileTTF(argv[1],18.f); unsigned char* tex;int tw,th;io.Fonts->GetTexDataAsRGBA32(&tex,&tw,&th);io.Fonts->SetTexID((ImTextureID)1);
 auto& st=ImGui::GetStyle();st.WindowPadding={8,8};st.ItemSpacing={8,3};st.FramePadding={3,3};st.WindowRounding=3;st.FrameRounding=3;st.WindowBorderSize=1;st.Colors[ImGuiCol_Text]={.96f,.90f,.92f,1};st.Colors[ImGuiCol_WindowBg]={.05f,.03f,.04f,1};st.Colors[ImGuiCol_Border]={.39f,.09f,.14f,1};st.Colors[ImGuiCol_TitleBg]=st.Colors[ImGuiCol_TitleBgActive]={.55f,.06f,.17f,1};st.Colors[ImGuiCol_Button]={.21f,.07f,.10f,1};
 std::vector<Panel> panels={
 {"Bypass",{"Unlock Icons","Unlock Main Levels","Unlock Vaults","Unlock Shops","Unlock Paths","Character Filter Bypass","Character Limit Bypass","Practice Music Sync","Music Customizer","Checkpoint Limit","Pause Buffering","Quick Chests","Allow Low Volume","Instant Complete"},10,76,447},
 {"Cosmetic",{"Force Don't Enter","Force Don't Fade","Hide Attempts","Hide Pause Button","Hide Pause Menu","No New Best Popup","No Death Effect","No Force Glow","No Object Glow","No Ghost Trail","No Hide Trigger","No Mirror","No Rotation","No Pulse","No Particles","No Portal Lightning","No Respawn Flash","No Spider Dash","No Wave Pulse","No Wave Trail","No Wave Trail Behind","Stable Pulse","Stop Triggers on Death","Always Show Trail","Solid Wave Trail"},237,76,801},
 {"Creator",{"Absolute Position","Absolute Scaling","Level Copy Bypass","Custom Object Bypass","Default Song Bypass","Free Scroll","Hide UI","Hide Triggers","Level Edit","No (C) Mark","No Editor Trail","Rotation Hack","Slider Limit","Smooth Editor Trail","Verify Bypass","Z Order Bypass","Zoom / Playtest Zoom"},464,76,586},
 {"Level",{"0% Practice Completion","Auto LDM","Auto Practice Mode","Auto Pickup Coins","Auto Song Download","Freeze Attempts","Freeze Player","Hitbox Multiplier","Ignore ESC","No Hitbox","No Solids","No Spikes","Everything Hurts","Force Visibility","Noclip","Jump Hack","Pause During Complete","Practice Fix","Practice Coins","Show Hitboxes","Layout Mode","Smart StartPos","StartPos Switcher","Show Trajectory"},691,76,773},
 {"Universal",{"Safe Mode","Auto Safe Mode","Speedhack","Audio Speed","Physics Bypass","FPS Bypass","Vertical Sync","Transition Speed","Transparent Lists","Lock Cursor","Mute on Unfocus","Free Window Resize","Unfocused FPS","Auto Deafen","Thread Priority","Discord RPC"},918,76,561},
 {"Status",{"Cheat Indicator","Show Labels","Percentage","FPS","CPS","Noclip Accuracy","Noclip Deaths","Session Time","Clock","Best Run","Attempts","Jumps","Message"},1145,76,466},
 {"Icons",{"Player 1  /  Player 2","Colour 1: Custom","Colour 2: No Effect","Glow: No Effect","Trail: No Effect","Wave: Rainbow","Particles: No Effect","Cycle Speed: 1.00x","Same Dual Colour","Inversed Trail","No Orb Ring","Icon Randomiser"},1372,76,437},
 {"GxLx",{"Save configuration","GRIEF / SLAUGHTERHOUSE","Presets and keybinds","Native Geode menu","Based on Eclipse 1.9.4"},10,538,237},
 {"Replay",{"Record / Play / Disable","Frame Stepper","Ignore Inputs","Save / Load Replay","Open Replays Folder"},464,677,217},
 {"Display",{"Smooth Fix","Force Smooth Fix","Low Detail","Windowed","1600 x 900   Set size","Screenshot (PNG)"},918,652,267},
 {"Shortcuts",{"Restart Level","Toggle Practice Mode","Place / Remove Checkpoint","Show Level Password","Options / Graphics","Save Folder"},1145,557,247},
 {"Theme",{"Black glass","Crimson gradients","Spin / fly-in animation","Custom menu hotkey"},1372,528,207}
 };
 for(int frame=0;frame<3;++frame){
 ImGui::NewFrame();if(menuOpen) gxlx::style::drawHeader(1.f);
 for(auto const& panel:panels){ImGui::SetNextWindowPos({panel.x,panel.y});ImGui::SetNextWindowSize({218,panel.h});ImGui::Begin(panel.title.c_str(),nullptr,ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoScrollbar);gxlx::style::decorateWindow(panel.title.c_str(),false,1);
 for(auto const& row:panel.rows){bool active=row=="Auto Safe Mode" || row=="Show Hitboxes" || row=="FPS" || row=="StartPos Switcher";auto p=ImGui::GetCursorScreenPos();ImGui::PushStyleColor(ImGuiCol_Text,active?ImVec4(1,.9f,.94f,1):ImVec4(.70f,.55f,.60f,1));ImGui::PushStyleColor(ImGuiCol_Button,ImVec4(0,0,0,0));ImGui::PushStyleVar(ImGuiStyleVar_ButtonTextAlign,{0,.5f});ImGui::Button(row.c_str(),{202,24});ImGui::PopStyleVar();ImGui::PopStyleColor(2);ImGui::GetWindowDrawList()->AddRectFilled({p.x+196,p.y+7},{p.x+199,p.y+19},active?IM_COL32(255,46,79,255):IM_COL32(67,29,41,255));}
 ImGui::End();}
 if(reveal<1.f)gxlx::motion::animateMenuWindows(reveal);
 if(menuOpen)gxlx::style::drawFooter(1.f,ImTextureRef((ImTextureID)2));
 ImGui::Render();}

 auto* data=ImGui::GetDrawData();std::vector<unsigned char> pixels(W*H*3,7);
 for(int l=0;l<data->CmdListsCount;++l){auto* list=data->CmdLists[l];for(auto const& cmd:list->CmdBuffer){if(cmd.UserCallback)continue;for(unsigned int i=0;i+2<cmd.ElemCount;i+=3){
 ImDrawVert v[3];for(int j=0;j<3;++j)v[j]=list->VtxBuffer[list->IdxBuffer[cmd.IdxOffset+i+j]+cmd.VtxOffset];float area=edge(v[0].pos,v[1].pos,v[2].pos.x,v[2].pos.y);if(std::abs(area)<1e-5f)continue;
 int x0=std::max({0,(int)std::floor(std::min({v[0].pos.x,v[1].pos.x,v[2].pos.x})),(int)cmd.ClipRect.x}),x1=std::min({W,(int)std::ceil(std::max({v[0].pos.x,v[1].pos.x,v[2].pos.x})),(int)cmd.ClipRect.z});
 int y0=std::max({0,(int)std::floor(std::min({v[0].pos.y,v[1].pos.y,v[2].pos.y})),(int)cmd.ClipRect.y}),y1=std::min({H,(int)std::ceil(std::max({v[0].pos.y,v[1].pos.y,v[2].pos.y})),(int)cmd.ClipRect.w});
 for(int y=y0;y<y1;++y)for(int x=x0;x<x1;++x){float a=edge(v[1].pos,v[2].pos,x+.5f,y+.5f)/area,b=edge(v[2].pos,v[0].pos,x+.5f,y+.5f)/area,c=1-a-b;if(a<0||b<0||c<0)continue;float weights[3]={a,b,c};float uvx=0,uvy=0,col[4]{};for(int j=0;j<3;++j){uvx+=weights[j]*v[j].uv.x;uvy+=weights[j]*v[j].uv.y;for(int k=0;k<4;++k)col[k]+=weights[j]*((v[j].col>>(8*k))&255);}
 bool isLogo=cmd.GetTexID()==2;int texW=isLogo?1254:tw,texH=isLogo?1254:th;int tx=std::clamp((int)(uvx*texW),0,texW-1),ty=std::clamp((int)(uvy*texH),0,texH-1);auto* sample=(isLogo?logoPixels.data():tex)+(ty*texW+tx)*4;float alpha=col[3]/255.f*sample[3]/255.f;for(int k=0;k<3;++k){int n=(y*W+x)*3+k;pixels[n]=(unsigned char)(col[k]*sample[k]/255.f*alpha+pixels[n]*(1-alpha));}
 }}}}
 std::ofstream out(argv[2],std::ios::binary);out<<"P6\n"<<W<<" "<<H<<"\n255\n";out.write((char*)pixels.data(),pixels.size());std::cout<<"Rendered "<<data->TotalVtxCount<<" vertices; "<<panels.size()<<" panels\n";ImGui::DestroyContext();
}
