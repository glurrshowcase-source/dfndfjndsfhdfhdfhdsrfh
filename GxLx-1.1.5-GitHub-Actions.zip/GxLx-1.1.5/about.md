# GxLx 1.1.4

**GxLx** is a red-and-black mod menu for Geometry Dash on Windows with an ImGui interface, animations and gameplay/editor utilities.

## Controls

Press **Tab** to open and close the menu, or configure **Menu Keybind** in Geode settings.

## Features

- GxLx styling, animated panels, sound cue and logo
- Configurable hotkey and gameplay utilities
- Visual tools, StartPos Switcher and editor features
- Replay Bot and recording tools where available

## Developer

**GxLx**

## Community

[YouTube — @DJakDoki](https://www.youtube.com/@DJakDoki)

## Licensing

The modified base program is distributed under [EPL-2.0](https://www.eclipse.org/legal/epl-2.0/). Independently authored GxLx materials may be covered by the separate **GxLx Original Works License 1.0**. Full original authorship and third-party acknowledgments are preserved in `LICENSE.md`, `LICENSE-GXLX-ORIGINAL.md`, `NOTICE-GXLX.md`, and `README-UPSTREAM.md`.
