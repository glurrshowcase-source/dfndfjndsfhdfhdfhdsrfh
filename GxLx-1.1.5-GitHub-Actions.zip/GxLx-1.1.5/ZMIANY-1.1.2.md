# GxLx 1.1.2 — stały Slaughterhouse

- Usunięto przycisk Reload Fonts, wybór fontów i rozmiaru fontów z zakładki Interface.
- Usunięto wybór presetów, stylu ImGui oraz layoutu, a także edycję kolorów akcentu i tła.
- Usunięto sześć zbędnych presetów z zasobów. W paczce pozostaje tylko `gxlx-slaughterhouse.json`.
- Manager motywów zawsze ładuje Slaughterhouse, ignoruje przestarzałe `theme.json`, `themeIndex` i niestandardowe pliki motywów, także po aktualizacji.
- Z górnego banera usunięto `GRIEF / SLAUGHTERHOUSE`, a napis `GxLx` wycentrowano w pionie.
- Pozostawiono sterowanie keybindem, renderer ImGui, animacje, dźwięk i dolne logo.

## Status kompilacji

Ten pakiet zawiera **kod źródłowy**, a nie gotowe `.geode` 1.1.2.
Nie wykonano kompilacji Windows ani testu w grze w tym środowisku — brakuje tu SDK Geode 5.11.2 i zależności platformy Windows.
Plik `.geode` z archiwum 1.1.1 **nie jest** zaktualizowany i nie został dołączony, żeby uniknąć pomylenia wersji.
Do zbudowania na Windows użyj odpowiedniego toolchainu i skryptu `build-windows.ps1`; informacje o zależnościach są w `BUILD-INFO.md`.
