#pragma once
#ifndef GXLX_HPP
#define GXLX_HPP

#include "components.hpp" // Adding custom UI components to the menu
#include "config.hpp"     // Accessing the GxLx config file
#include "labels.hpp"     // Working with RIFT variables
#include "modules.hpp"    // Add custom modules to GxLx (e.g. register your mod as a cheat for auto safe mode)

#endif // GXLX_HPP
