# GxLx Original Works License, Version 1.0

Copyright (c) 2026 GxLx, **only for original works to which GxLx holds copyright**.

## 1. Scope

This license applies only to original, independently created material clearly identified as created by GxLx, to the extent that GxLx owns the relevant rights. This may include original GxLx branding assets, artwork, sound effects and independent code that does **not** incorporate pre-existing third-party licensed code.

This license **does not** replace the Eclipse Public License 2.0 (EPL-2.0) for the inherited or modified Eclipse Menu program. It does not cover the Geode SDK, Geometry Dash, third-party assets, fonts, libraries or other authors' contributions. Any original GxLx contribution that constitutes a modification of EPL-2.0 Program source code remains available under EPL-2.0 as required by that license.

## 2. Permission

For original works covered by this license, permission is granted, free of charge, to use, copy, modify and redistribute the material, including commercially, provided that:

1. The copyright and this license notice are preserved in redistributed copies or accompanying documentation.
2. Modified versions clearly indicate that changes were made.
3. No permission to use trademarks or to claim endorsement by GxLx is granted.
4. This license may not be used to remove or limit rights granted under another applicable open-source license.

## 3. Warranty disclaimer

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THE ORIGINAL MATERIAL IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED. THE COPYRIGHT HOLDER SHALL NOT BE LIABLE FOR DAMAGES ARISING FROM ITS USE, EXCEPT WHERE SUCH LIMITATION IS PROHIBITED BY LAW.

## 4. License precedence

If material contains inherited EPL-2.0 code, the source code and notices must remain available under EPL-2.0. If this document and the applicable third-party license conflict, the third-party license governs its own material. See `LICENSE.md`, `NOTICE-GXLX.md`, `README-UPSTREAM.md` and `resources/Licenses/`.

*This is a custom license for independently authored GxLx material, not a replacement for the source-code license of the complete mod.*
