#include "tabbed.hpp"
#include <modules/gui/imgui/gxlx-style.hpp>
#include <modules/gxlx/search.hpp>
#include <modules/i18n/translations.hpp>
#include <utils.hpp>
#include <modules/config/config.hpp>
#include <modules/gui/gui.hpp>
#include <modules/gui/components/base-component.hpp>
#include <modules/gui/imgui/imgui.hpp>
#include <modules/gui/theming/manager.hpp>

namespace gxlx::gui::imgui {

    void TabbedLayout::init() {
        m_windows.clear();

        // Load tabs
        auto& tabs = Engine::get().getTabs();
        m_windows.reserve(tabs.size());
        for (auto& tab : tabs) {
            m_windows.emplace_back(tab.getTitle(), [tab = &tab] {
                for (auto& component : tab->getComponents()) {
                    if (component->getFlags() & ComponentFlags::DisableTabbed) continue;
                    if (gxlx::search::active() &&
                        !gxlx::search::contains(i18n::get(component->getTitle())) &&
                        !gxlx::search::contains(component->getId())) continue;
                    ImGuiRenderer::get()->visitComponent(component.get());
                }
            });
        }

        // Load saved window states
        {
            auto windowStates = config::get("windows", std::vector<matjson::Value>());
            for (auto &windowState: windowStates) {
                auto title = windowState["title"].as<std::string>().unwrapOrDefault();
                auto window = std::ranges::find_if(m_windows, [&title](Window const& w) {
                    return w.getTitle() == title;
                });
                if (window != m_windows.end()) {
                    window->applyJson(windowState);
                    window->setDrawPosition(window->getPosition());
                }
            }
        }

        m_preloadStep = 0;
    }

    bool TabbedLayout::shouldRender() const {
        return m_reveal.visible() || m_preloadStep < 2;
    }

    bool TabbedLayout::wantStayVisible() const {
        return m_reveal.visible() || !m_actions.empty() || m_preloadStep < 2;
    }

    void TabbedLayout::draw() {
        if (m_preloadStep < 2) {
            // Measure at final coordinates while invisible. No off-screen culling.
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, 0.f);
            for (auto& window : m_windows) window.draw();
            ImGui::PopStyleVar();
            if (config::get<bool>("menu.stackWindows", true)) {
                for (auto& [window, position] : getStackedPositions()) {
                    window->setPosition(position);
                    window->setDrawPosition(position);
                }
            }
            ++m_preloadStep;
            return;
        }

        // Run move actions
        auto deltaTime = ImGui::GetIO().DeltaTime;
        for (auto const& action : m_actions)
            action->update(deltaTime);

        // Remove finished actions
        std::erase_if(m_actions, [](auto& action) {
            return action->isFinished();
        });

        if (!shouldRender()) return;

        auto* theme = ThemeManager::get();
        if (Engine::get().isToggled() && theme->getThemeName().starts_with("GxLx"))
            gxlx::style::drawHeader(theme->getGlobalScale());

        // Search all GxLx options from the menu header.
        if (Engine::get().isToggled()) {
            auto display = ImGui::GetIO().DisplaySize;
            auto scale = theme->getGlobalScale();
            if (display.x > 450.f * scale) {
                ImGui::SetNextWindowPos({220.f * scale, 9.f * scale}, ImGuiCond_Always);
                ImGui::SetNextWindowSize({std::min(360.f * scale, display.x - 238.f * scale), 46.f * scale}, ImGuiCond_Always);
                ImGui::Begin("##GxLxSearch", nullptr,
                    ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                    ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar |
                    ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoSavedSettings);
                ImGui::SetNextItemWidth(-1.f);
                ImGui::InputTextWithHint("##query", "Search GxLx functions...", gxlx::search::query, sizeof(gxlx::search::query));
                ImGui::End();
            }
        }

        // Render only matching categories; clear input to restore the complete menu.
        for (auto& window : m_windows) {
            if (gxlx::search::active()) {
                bool found = gxlx::search::contains(i18n::get(window.getTitle()));
                if (!found) {
                    for (auto const& tab : Engine::get().getTabs()) {
                        if (tab.getTitle() != window.getTitle()) continue;
                        for (auto const& component : tab.getComponents()) {
                            if (gxlx::search::contains(i18n::get(component->getTitle())) ||
                                gxlx::search::contains(component->getId())) { found = true; break; }
                        }
                    }
                }
                if (!found) continue;
            }
            window.draw();
        }

        // Auto reset window positions
        auto isDragging = config::getTemp<"draggingWindow">(false);
        auto stackEnabled = config::get<"menu.stackWindows", bool>(true);
        if (m_actions.empty() && !m_reveal.moving() && !isDragging && stackEnabled)
            stackWindows();

        // Reset dragging state
        config::setTemp("draggingWindow", false);

        if (m_actions.empty() && !m_reveal.moving()) {
            m_canForceKeyboardFocus = false;
        }
    }

    void TabbedLayout::toggle(bool state) {
        m_canForceKeyboardFocus = state;

        if (!state) {
            // Save window states
            std::vector<matjson::Value> windowStates;
            for (auto& window : m_windows) {
                windowStates.push_back(window);
            }
            config::set("windows", windowStates);
        }

        m_actions.clear();
        m_reveal.target(state);
        if (!config::get<bool>("menu.animateWindows", true)) m_reveal.snap(state);
        for (auto& window : m_windows) window.setDrawPosition(window.getPosition());
    }

    /// @brief Calculate a random window position outside the screen.
    ImVec2 TabbedLayout::randomWindowPosition(Window const& window) {
        // Calculate target position randomly to be outside the screen
        auto screenSize = ImGui::GetIO().DisplaySize;
        auto windowSize = window.getSize();
        ImVec2 target;

        // Pick a random side of the screen
        switch (utils::random(3)) {
            case 0:
                target = ImVec2(utils::random(screenSize.x - windowSize.x), -windowSize.y);
                break;
            case 1:
                target = ImVec2(utils::random(screenSize.x - windowSize.x), screenSize.y);
                break;
            case 2:
                target = ImVec2(-windowSize.x, utils::random(screenSize.y - windowSize.y));
                break;
            default:
                target = ImVec2(screenSize.x, utils::random(screenSize.y - windowSize.y));
                break;
        }

        return target;
    }

    /// @brief Auto-stacks windows on screen.
    std::vector<std::pair<Window*, ImVec2>> TabbedLayout::getStackedPositions() {
        auto firstColumnLock = config::get<"menu.lockFirstColumn", bool>(false);
        constexpr std::array<std::string_view, 2> BuiltInWindows = {"tab.interface", "tab.keybinds"};

        auto tm = ThemeManager::get();
        auto const scale = tm->getGlobalScale();
        auto margin = tm->getWindowMargin() * scale;
        ImVec2 screenSize = ImGui::GetIO().DisplaySize;

        float windowWidth = Window::MIN_SIZE.x * scale;
        auto columns = std::max(1, static_cast<int>((screenSize.x - margin) / (windowWidth + margin)));
        if (columns == 1) firstColumnLock = false;
        float top = margin + (tm->getThemeName().starts_with("GxLx") ? gxlx::style::headerHeight(scale) : 0.f);

        float freeSpace = margin;
        if (config::get<"menu.horizontallyCenter", bool>(true)) {
            freeSpace += (screenSize.x - margin - (columns * (windowWidth + margin))) * 0.5f;
        }

        std::vector<std::pair<Window*, ImVec2>> positions;
        positions.reserve(m_windows.size());

        // Built-ins go into first column
        float x = freeSpace;
        float y = top;
        if (firstColumnLock) {
            for (auto title : BuiltInWindows) {
                auto it = std::ranges::find_if(m_windows, [&title](Window const& window) {
                    return window.getTitle() == title;
                });

                if (it != m_windows.end()) {
                    positions.emplace_back(&(*it), ImVec2(x, y));
                    y += it->getSize().y + margin;
                }
            }
        }

        if (columns <= 0) return positions;

        // Rest are stacked to take as little space as possible
        auto columnCount = firstColumnLock ? columns - 1 : columns;
        std::vector<float> heights(columnCount, top);
        for (auto& window : m_windows) {
            if (gxlx::search::active()) {
                bool found = gxlx::search::contains(i18n::get(window.getTitle()));
                if (!found) {
                    for (auto const& tab : Engine::get().getTabs()) {
                        if (tab.getTitle() != window.getTitle()) continue;
                        for (auto const& component : tab.getComponents()) {
                            if (gxlx::search::contains(i18n::get(component->getTitle())) ||
                                gxlx::search::contains(component->getId())) { found = true; break; }
                        }
                    }
                }
                if (!found) continue;
            }
            // Skip built-in windows
            if (firstColumnLock && std::ranges::find(BuiltInWindows, window.getTitle()) != BuiltInWindows.end())
                continue;

            // Find the column with the smallest height
            auto min = std::ranges::min_element(heights);
            auto index = std::distance(heights.begin(), min);

            // Set the position
            auto windowColumn = firstColumnLock ? index + 1 : index;
            positions.emplace_back(&window, ImVec2(static_cast<float>(windowColumn) * (windowWidth + margin) + freeSpace, *min));
            *min += window.getSize().y + margin;

            // Update the height
            heights[index] = *min;
        }

        return positions;
    }

    void TabbedLayout::stackWindows() {
        double duration = config::get<"menu.animationDuration", double>(0.3);
        auto easingType = config::get<"menu.animationEasingType", animation::Easing>(animation::Easing::Quadratic);
        auto easingMode = config::get<"menu.animationEasingMode", animation::EasingMode>(animation::EasingMode::EaseInOut);
        auto easing = animation::getEasingFunction(easingType, easingMode);

        for (auto& [window, target] : getStackedPositions()) {
            // Check if the window is already in the correct position
            if (window->getPosition().x == target.x && window->getPosition().y == target.y)
                continue;

            m_actions.push_back(window->animateTo(target, duration, easing, true));
        }
    }
}
