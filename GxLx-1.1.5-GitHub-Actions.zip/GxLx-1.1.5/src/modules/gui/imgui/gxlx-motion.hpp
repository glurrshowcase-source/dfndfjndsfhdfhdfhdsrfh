// Clip before rotating: scrolling rows must never spill outside a flying panel.
#pragma once
#include <imgui.h>
#include <imgui_internal.h>
#include <modules/gxlx/motion.hpp>
#include <array>
#include <vector>

namespace gxlx::motion {
    inline ImDrawVert interpolate(ImDrawVert a, ImDrawVert b, float t) {
        ImDrawVert v;
        v.pos = {a.pos.x+(b.pos.x-a.pos.x)*t, a.pos.y+(b.pos.y-a.pos.y)*t};
        v.uv = {a.uv.x+(b.uv.x-a.uv.x)*t, a.uv.y+(b.uv.y-a.uv.y)*t};
        v.col = 0;
        for (int shift=0; shift<32; shift+=8) {
            float x = float((a.col >> shift)&255), y = float((b.col >> shift)&255);
            v.col |= ImU32(std::clamp(x+(y-x)*t, 0.f, 255.f)) << shift;
        }
        return v;
    }

    inline void relocateDrawList(ImDrawList* src, ImDrawList* dst, ImVec2 center, Pose pose) {
        const float angle = pose.rotation * .017453292519943295f;
        const float cs = std::cos(angle)*pose.scale, sn = std::sin(angle)*pose.scale;
        dst->PushClipRectFullScreen();
        for (auto& cmd : src->CmdBuffer) {
            if (cmd.UserCallback) continue;
            dst->PushTexture(cmd.TexRef);
            const float bounds[4] = {cmd.ClipRect.x, cmd.ClipRect.y, cmd.ClipRect.z, cmd.ClipRect.w};
            for (unsigned i=0; i+2<cmd.ElemCount; i+=3) {
                std::array<ImDrawVert, 12> polygon{}, scratch{};
                int count = 3;
                for (int j=0;j<3;j++) polygon[j] = src->VtxBuffer[src->IdxBuffer[cmd.IdxOffset+i+j]+cmd.VtxOffset];
                for (int side=0; side<4 && count; ++side) {
                    auto distance = [=](ImDrawVert const& v) {
                        float c = side%2 ? v.pos.y : v.pos.x;
                        return side<2 ? c-bounds[side] : bounds[side]-c;
                    };
                    int n = 0;
                    auto previous = polygon[count-1];
                    float dp = distance(previous);
                    for (int j=0;j<count;++j) {
                        auto current = polygon[j];
                        float dc = distance(current);
                        if ((dc>=0) != (dp>=0)) scratch[n++] = interpolate(previous, current, dp/(dp-dc));
                        if (dc>=0) scratch[n++] = current;
                        previous = current; dp = dc;
                    }
                    polygon = scratch; count = n;
                }
                if (count<3) continue;
                for (int j=0;j<count;++j) {
                    auto& v = polygon[j];
                    const float x=v.pos.x-center.x, y=v.pos.y-center.y;
                    v.pos = {center.x+x*cs-y*sn+pose.x, center.y+x*sn+y*cs+pose.y};
                    auto alpha = ImU32(((v.col >> IM_COL32_A_SHIFT)&255)*pose.alpha);
                    v.col = (v.col & ~IM_COL32_A_MASK) | (alpha << IM_COL32_A_SHIFT);
                }
                dst->PrimReserve((count-2)*3, (count-2)*3);
                for (int j=1;j<count-1;++j) {
                    for (int k : {0,j,j+1}) dst->PrimVtx(polygon[k].pos, polygon[k].uv, polygon[k].col);
                }
            }
            dst->PopTexture();
            cmd.ElemCount = 0; // the clipped, transformed copy replaces the original
        }
        dst->PopClipRect();
    }

    inline void animateMenuWindows(float reveal) {
        auto* ctx = ImGui::GetCurrentContext();
        std::vector<ImGuiWindow*> roots;
        for (auto* w : ctx->Windows)
            if (w->Active && w->LastFrameActive == ctx->FrameCount && !w->IsFallbackWindow &&
                !(w->Flags & (ImGuiWindowFlags_ChildWindow | ImGuiWindowFlags_Popup | ImGuiWindowFlags_Tooltip))) roots.push_back(w);
        auto display = ImGui::GetIO().DisplaySize;
        auto* dest = ImGui::GetForegroundDrawList();
        for (int i=0; i<static_cast<int>(roots.size()); ++i) {
            auto* root = roots[i];
            auto pose = sample(reveal, i, static_cast<int>(roots.size()), display.x, display.y);
            if (pose.rotation == 0.f && pose.alpha == 1.f) continue;
            ImVec2 center{root->Pos.x+root->Size.x*.5f, root->Pos.y+root->Size.y*.5f};
            auto visit = [&](auto&& self, ImGuiWindow* w) -> void {
                if (!w->Active || w->LastFrameActive != ctx->FrameCount) return;
                relocateDrawList(w->DrawList, dest, center, pose);
                for (auto* child : w->DC.ChildWindows) self(self, child);
            };
            visit(visit, root);
        }
    }
}
