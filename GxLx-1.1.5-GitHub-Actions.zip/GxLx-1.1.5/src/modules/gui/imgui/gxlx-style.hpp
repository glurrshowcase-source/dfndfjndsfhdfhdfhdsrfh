// GxLx additions, 2026-11-08. Distributed under EPL-2.0; see LICENSE.md.
#pragma once
#include <imgui.h>
#include <algorithm>

namespace gxlx::style {
    inline ImU32 color(int r, int g, int b, int a = 255) {
        return IM_COL32(r, g, b, int(a * ImGui::GetStyle().Alpha));
    }

    // Shared by the in-game renderer and the standalone visual smoke test.
    inline void decorateWindow(const char* title, bool collapsed, float scale) {
        const auto p = ImGui::GetWindowPos();
        const auto size = ImGui::GetWindowSize();
        const float h = ImGui::GetFrameHeight();
        auto* draw = ImGui::GetWindowDrawList();
        draw->PushClipRect(p, {p.x + size.x, p.y + size.y}, false);
        if (!collapsed) {
            draw->AddRectFilledMultiColor({p.x + 1, p.y + h}, {p.x + size.x - 1, p.y + size.y - 1},
                color(38, 8, 17, 245), color(12, 8, 11, 245),
                color(9, 7, 10, 245), color(20, 7, 12, 245));
            const float x = p.x + size.x - 2, y = p.y + size.y - 2;
            draw->AddTriangleFilled({x - 32*scale, y}, {x, y - 27*scale}, {x, y}, color(79, 10, 28, 70));
        }
        draw->AddRectFilledMultiColor(p, {p.x + size.x, p.y + h},
            color(160, 17, 46), color(46, 7, 18), color(46, 7, 18), color(105, 12, 34));
        draw->AddLine({p.x, p.y + h}, {p.x + size.x, p.y + h}, color(235, 36, 70, 175));
        const auto textSize = ImGui::CalcTextSize(title);
        draw->AddText({p.x + (size.x-textSize.x)*.5f, p.y + (h-textSize.y)*.5f}, color(255, 240, 244), title);
        const float ax = p.x + 8*scale, ay = p.y + h*.5f;
        if (collapsed)
            draw->AddTriangleFilled({ax, ay-3*scale}, {ax+5*scale,ay}, {ax,ay+3*scale}, color(255,175,192));
        else
            draw->AddTriangleFilled({ax,ay-2*scale}, {ax+6*scale,ay-2*scale}, {ax+3*scale,ay+3*scale}, color(255,175,192));
        draw->PopClipRect();
    }

    inline float headerHeight(float scale) { return 64.f * scale; }

    inline void drawHeader(float scale) {
        const float width = ImGui::GetIO().DisplaySize.x;
        const float height = headerHeight(scale);
        auto* draw = ImGui::GetBackgroundDrawList();
        draw->AddRectFilledMultiColor({0,0}, {width,height}, color(70,4,19), color(9,7,10), color(9,7,10), color(24,5,13));
        draw->AddRectFilled({0,0}, {4*scale,height}, color(247,31,67));
        // Center the brand vertically, without the previous subtitle.
        const auto brandSize = ImGui::GetFont()->CalcTextSizeA(30*scale, 10000, 0, "GxLx");
        draw->AddText(ImGui::GetFont(), 30*scale, {20*scale, (height-brandSize.y)*.5f}, color(255,238,243), "GxLx");
        const char* info = "GD 2.2081  /  GEODE 5.11.2";
        const auto textSize = ImGui::GetFont()->CalcTextSizeA(12*scale, 10000, 0, info);
        if (width > 600*scale)
            draw->AddText(ImGui::GetFont(),12*scale,{width-textSize.x-20*scale,25*scale},color(203,150,164),info);
        draw->AddLine({0,height},{width,height},color(153,23,48),scale);
        for (int i=0;i<3;i++) {
            float x=195*scale+i*15*scale;
            draw->AddTriangleFilled({x,16*scale},{x+7*scale,29*scale},{x,42*scale},color(133,15,42,125-i*25));
        }
    }
    inline float footerHeight(float scale) { return 58.f * scale; }

    inline void drawFooter(float scale, ImTextureRef logo) {
        auto size = ImGui::GetIO().DisplaySize;
        const float height = footerHeight(scale), y = size.y-height;
        auto* draw = ImGui::GetForegroundDrawList();
        draw->AddRectFilledMultiColor({0,y},{size.x,size.y},color(32,2,10,248),color(8,4,7,248),color(3,2,4,255),color(12,2,6,255));
        draw->AddLine({0,y},{size.x,y},color(178,17,45),scale);
        const char* text = "GXLX menu";
        auto textSize = ImGui::GetFont()->CalcTextSizeA(21*scale,10000,0,text);
        const float left = (size.x-textSize.x-58*scale)*.5f;
        if (logo.GetTexID() != ImTextureID_Invalid)
            draw->AddImage(logo,{left,y+6*scale},{left+46*scale,y+52*scale});
        draw->AddText(ImGui::GetFont(),21*scale,{left+58*scale,y+(height-textSize.y)*.5f},color(255,227,235),text);
    }

}
