// GxLx easter eggs. Windows-only media presentation; original GxLx implementation.
#include "easter-eggs.hpp"
#include "branding.hpp"
#include <Geode/Geode.hpp>
#include <modules/gui/gui.hpp>
#include <imgui.h>
#include <chrono>
#include <deque>
#include <filesystem>
#include <atomic>
#include <string>

#ifdef GEODE_IS_WINDOWS
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <mfapi.h>
#include <mfplay.h>
#endif

using namespace geode::prelude;
using namespace std::chrono;

namespace gxlx::eggs {
    namespace {
        constexpr int SECRET_LEVEL_ID = 151673976;
        using Clock = steady_clock;
        std::deque<Clock::time_point> menuPresses;
        int sequenceIndex = 0;
        Clock::time_point lastSequenceKey{};

        class SecretLevelDelegate : public LevelDownloadDelegate {
        public:
            void levelDownloadFinished(GJGameLevel* level) override {
                GameLevelManager::sharedState()->m_levelDownloadDelegate = nullptr;
                if (!level || level->m_levelString.empty()) {
                    geode::Notification::create("GxLx: level could not be loaded", geode::NotificationIcon::Error)->show();
                    return;
                }
                enter(level);
            }
            void levelDownloadFailed(int) override {
                GameLevelManager::sharedState()->m_levelDownloadDelegate = nullptr;
                geode::Notification::create("GxLx: level download failed", geode::NotificationIcon::Error)->show();
            }
            static void enter(GJGameLevel* level) {
                if (gui::Engine::get().isToggled()) gui::Engine::get().toggle();
                auto* director = CCDirector::sharedDirector();
                auto* scene = PlayLayer::scene(level, false, false);
                if (scene) director->replaceScene(CCTransitionFade::create(0.25f, scene));
            }
        } levelDelegate;

        void openSecretLevel() {
            auto* manager = GameLevelManager::sharedState();
            if (!manager) return;
            if (auto* level = manager->getSavedLevel(SECRET_LEVEL_ID);
                level && !level->m_levelString.empty()) {
                SecretLevelDelegate::enter(level);
                return;
            }
            // Do not override another mod or the game's currently active download callback.
            if (manager->m_levelDownloadDelegate) {
                geode::Notification::create("GxLx: finish your current level download first", geode::NotificationIcon::Warning)->show();
                return;
            }
            manager->m_levelDownloadDelegate = &levelDelegate;
            manager->downloadLevel(SECRET_LEVEL_ID, false, 0);
            geode::Notification::create("GxLx: loading secret level", geode::NotificationIcon::Info)->show();
        }

#ifdef GEODE_IS_WINDOWS
        std::atomic<bool> videoEnded{false};
        bool movieActive = false;
        HWND movieWindow = nullptr;
        HWND gameWindow = nullptr;
        IMFPMediaPlayer* mediaPlayer = nullptr;
        bool mfStarted = false;
        bool comStarted = false;
        Clock::time_point movieStarted{};

        class MovieCallback final : public IMFPMediaPlayerCallback {
            std::atomic<ULONG> refs{1};
        public:
            STDMETHODIMP QueryInterface(REFIID iid, void** result) override {
                if (!result) return E_POINTER;
                *result = nullptr;
                if (iid == IID_IUnknown || iid == __uuidof(IMFPMediaPlayerCallback)) {
                    *result = static_cast<IMFPMediaPlayerCallback*>(this);
                    AddRef();
                    return S_OK;
                }
                return E_NOINTERFACE;
            }
            STDMETHODIMP_(ULONG) AddRef() override { return ++refs; }
            STDMETHODIMP_(ULONG) Release() override {
                ULONG next = --refs;
                if (!next) delete this;
                return next;
            }
            STDMETHODIMP_(void) OnMediaPlayerEvent(MFP_EVENT_HEADER* event) override {
                if (!event) return;
                if (FAILED(event->hrEvent) || event->eEventType == MFP_EVENT_TYPE_PLAYBACK_ENDED)
                    videoEnded.store(true);
            }
        };

        void stopMovie() {
            // Called on the game thread; callbacks only set a thread-safe flag.
            if (mediaPlayer) {
                mediaPlayer->Shutdown();
                mediaPlayer->Release();
                mediaPlayer = nullptr;
            }
            if (movieWindow) { DestroyWindow(movieWindow); movieWindow = nullptr; }
            if (mfStarted) { MFShutdown(); mfStarted = false; }
            if (comStarted) { CoUninitialize(); comStarted = false; }
            movieActive = false;
            gameWindow = nullptr;
            menuPresses.clear();
        }

        void beginMovie() {
            if (movieActive) return;
            auto videoFile = gxlx::resource("10clicks.mp4");
            if (!std::filesystem::exists(videoFile)) {
                geode::Notification::create("GxLx: missing 10clicks.mp4", geode::NotificationIcon::Error)->show();
                return;
            }
            gameWindow = GetForegroundWindow();
            DWORD owningPID = 0;
            GetWindowThreadProcessId(gameWindow, &owningPID);
            if (!gameWindow || owningPID != GetCurrentProcessId()) {
                geode::Notification::create("GxLx: game window not found", geode::NotificationIcon::Error)->show();
                return;
            }
            RECT client{};
            GetClientRect(gameWindow, &client);
            movieWindow = CreateWindowExW(0, L"STATIC", L"", WS_CHILD | WS_VISIBLE | SS_BLACKRECT,
                0, 0, client.right, client.bottom, gameWindow, nullptr, GetModuleHandleW(nullptr), nullptr);
            if (!movieWindow) return;
            SetWindowPos(movieWindow, HWND_TOP, 0, 0, client.right, client.bottom, SWP_SHOWWINDOW);
            HRESULT comResult = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
            comStarted = SUCCEEDED(comResult);
            if (FAILED(comResult) && comResult != RPC_E_CHANGED_MODE) { stopMovie(); return; }
            if (FAILED(MFStartup(MF_VERSION))) { stopMovie(); return; }
            mfStarted = true;
            videoEnded.store(false);
            auto* callback = new MovieCallback();
            HRESULT hr = MFPCreateMediaPlayer(videoFile.wstring().c_str(), TRUE, static_cast<MFP_CREATION_OPTIONS>(0), callback, movieWindow, &mediaPlayer);
            callback->Release();
            if (FAILED(hr) || !mediaPlayer) {
                stopMovie();
                geode::Notification::create("GxLx: video playback unavailable", geode::NotificationIcon::Error)->show();
                return;
            }
            movieActive = true;
            movieStarted = Clock::now();
            if (gui::Engine::get().isToggled()) gui::Engine::get().toggle();
        }
#else
        bool movieActive = false;
        void beginMovie() { geode::log::warn("GxLx video egg requires Windows"); }
#endif
    }

    bool isMoviePlaying() { return movieActive; }

    bool onMenuKeyPressed(gxlx::keybinds::KeyEvent const& event) {
        if (movieActive) return true;
        if (!event.down) return false;
        auto now = Clock::now();
        menuPresses.push_back(now);
        while (!menuPresses.empty() && (now-menuPresses.front()) > seconds(10))
            menuPresses.pop_front();
        if (menuPresses.size() >= 10) {
            menuPresses.clear();
            beginMovie();
            return true;
        }
        return false;
    }

    bool onAnyKey(gxlx::keybinds::KeyEvent const& event) {
        if (movieActive) return true;
        if (!event.down) return false;
        if (ImGui::GetCurrentContext() && ImGui::GetIO().WantTextInput) { sequenceIndex = 0; return false; }
        constexpr gxlx::keybinds::Keys sequence[] = {
            gxlx::keybinds::Keys::G, gxlx::keybinds::Keys::X,
            gxlx::keybinds::Keys::L, gxlx::keybinds::Keys::X
        };
        auto now = Clock::now();
        if (now - lastSequenceKey > seconds(3)) sequenceIndex = 0;
        lastSequenceKey = now;
        if (event.props.key == sequence[sequenceIndex]) ++sequenceIndex;
        else sequenceIndex = event.props.key == sequence[0] ? 1 : 0;
        if (sequenceIndex == 4) {
            sequenceIndex = 0;
            openSecretLevel();
            return true;
        }
        return false;
    }

    void tick() {
#ifdef GEODE_IS_WINDOWS
        if (!movieActive) return;
        if (videoEnded.load() || Clock::now() - movieStarted > seconds(40)) {
            stopMovie();
            return;
        }
        if (!IsWindow(gameWindow)) { stopMovie(); return; }
        RECT r{};
        GetClientRect(gameWindow, &r);
        SetWindowPos(movieWindow, HWND_TOP, 0, 0, r.right, r.bottom, SWP_NOACTIVATE | SWP_SHOWWINDOW);
#endif
    }
}
