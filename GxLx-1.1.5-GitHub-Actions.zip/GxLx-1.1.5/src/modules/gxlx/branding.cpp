// GxLx presentation, EPL-2.0.
#include "branding.hpp"
#include <Geode/Geode.hpp>
#include <modules/config/config.hpp>
#include <modules/gui/imgui/gxlx-style.hpp>

namespace gxlx {
    std::filesystem::path resource(char const* name) {
        return geode::Mod::get()->getResourcesDir() / name;
    }

    void migrateSettings() {
        using namespace gxlx;
        bool changed = false;
        if (!config::get<bool>("gxlx.presentation-v1.1", false)) {
            auto old = geode::utils::file::readJson(geode::Mod::get()->getSaveDir() / "settings.json");
            if (old) config::set("gxlx.legacy-render", old.unwrap()["legacy-render"].asBool().unwrapOr(false));
            config::set("menu.animateWindows", true);
            config::set("gxlx.presentation-v1.1", true);
            changed = true;
        }
        // Normalize old saves too. The obsolete selector is never read by the renderer.
        if (config::get<int>("gxlx.renderer", -1) != 0) {
            config::set("gxlx.renderer", 0);
            changed = true;
        }
        // menu.toggleKey and gameplay options are deliberately left untouched.
        if (changed) config::save();
    }

    void playToggleSound() {
        auto* engine = FMODAudioEngine::get();
        static int previous = -1;
        auto path = geode::utils::string::pathToString(resource("gxlx.mp3"));
        // Never stop an unrelated effect if GD has reused the channel ID.
        auto it = engine->m_channelIDToSoundPath.find(previous);
        if (it != engine->m_channelIDToSoundPath.end() && it->second == path)
            engine->stopChannel(previous);
        previous = engine->playEffect(path);
    }

    void drawImGuiFooter(float scale) {
        auto path = geode::utils::string::pathToString(resource("gxlx-logo.png"));
        // Look up the texture each frame so texture reloads cannot leave a stale GL ID.
        auto* texture = cocos2d::CCTextureCache::get()->addImage(path.c_str(), false);
        style::drawFooter(scale, texture ? ImTextureRef(static_cast<ImTextureID>(texture->getName())) : ImTextureRef{});
    }
}
