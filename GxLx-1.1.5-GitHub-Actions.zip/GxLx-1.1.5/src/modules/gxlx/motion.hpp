// GxLx presentation, EPL-2.0. Pure animation math for ImGui.
#pragma once
#include <algorithm>
#include <cmath>

namespace gxlx::motion {
    struct Pose { float x = 0, y = 0, rotation = 0, scale = 1, alpha = 1; };

    class Reveal {
        float m_value = 0;
        bool m_open = false;
    public:
        void target(bool open) { m_open = open; }
        void advance(float dt) {
            // Reverse from the current position when the hotkey is pressed rapidly.
            m_value = std::clamp(m_value + (m_open ? 1.f : -1.f) * std::max(dt, 0.f) / .78f, 0.f, 1.f);
        }
        void snap(bool open) { m_open = open; m_value = open ? 1.f : 0.f; }
        float value() const { return m_value; }
        bool open() const { return m_open; }
        bool moving() const { return m_open ? m_value < 1.f : m_value > 0.f; }
        bool visible() const { return m_open || m_value > 0.f; }
    };

    inline Pose sample(float reveal, int slot, int count, float width, float height) {
        const float delay = count > 1 ? .22f * slot / (count - 1) : 0.f;
        const float p = std::clamp((reveal - delay) / .78f, 0.f, 1.f);
        if (p >= 1.f) return {};
        const float t = p - 1.f;
        const float ease = 1.f + 2.15f*t*t*t + 1.15f*t*t;
        const float sign = slot % 2 ? 1.f : -1.f;
        return {sign * width * .72f * (1.f-ease),
                height * (.28f + .08f*(slot%3)) * (1.f-ease),
                sign * 240.f * (1.f-p) * (1.f-p),
                .55f + .45f*ease,
                std::clamp(p * 4.f, 0.f, 1.f)};
    }
}
