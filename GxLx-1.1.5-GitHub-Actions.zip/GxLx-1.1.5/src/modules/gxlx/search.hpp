#pragma once
#include <algorithm>
#include <cctype>
#include <string>
#include <string_view>

namespace gxlx::search {
    inline char query[128] = {};
    inline bool active() { return query[0] != '\0'; }
    inline bool contains(std::string_view haystack) {
        if (!active()) return true;
        std::string text(haystack), needle(query);
        std::transform(text.begin(), text.end(), text.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });
        std::transform(needle.begin(), needle.end(), needle.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });
        return text.find(needle) != std::string::npos;
    }
}
