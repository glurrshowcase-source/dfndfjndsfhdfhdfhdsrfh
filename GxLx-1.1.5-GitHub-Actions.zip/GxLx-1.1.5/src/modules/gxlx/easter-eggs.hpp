#pragma once
#include <modules/keybinds/manager.hpp>

namespace gxlx::eggs {
    // Returns true when an active easter egg consumes the normal menu hotkey.
    bool isMoviePlaying();
    bool onMenuKeyPressed(gxlx::keybinds::KeyEvent const& event);
    // Return true when the secret sequence key should be consumed.
    bool onAnyKey(gxlx::keybinds::KeyEvent const& event);
    void tick();
}
