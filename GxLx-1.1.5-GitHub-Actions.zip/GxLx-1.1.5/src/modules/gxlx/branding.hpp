#pragma once
#include <filesystem>


namespace gxlx {
    std::filesystem::path resource(char const* name);
    void migrateSettings();
    void playToggleSound();
    void drawImGuiFooter(float scale);
}
