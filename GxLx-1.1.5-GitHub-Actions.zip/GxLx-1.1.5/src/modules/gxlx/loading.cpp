// GxLx red neon loading cover, based on native GD progress to avoid fake progress values.
#include "branding.hpp"
#include <Geode/Geode.hpp>
#include <Geode/modify/LoadingLayer.hpp>
#include <algorithm>
#include <cmath>
#include <filesystem>

using namespace geode::prelude;

class $modify(GxLxLoadingLayer, LoadingLayer) {
    struct Fields {
        CCLayerColor* cover = nullptr;
        CCSprite* logo = nullptr;
        CCLayerColor* backGlow = nullptr;
        CCLayerColor* outerGlow = nullptr;
        CCLayerColor* frame = nullptr;
        CCLayerColor* track = nullptr;
        CCLayerGradient* fill = nullptr;
        CCLayerColor* fillGlow = nullptr;
        CCLayerColor* shine = nullptr;
        CCLabelTTF* percent = nullptr;
        float progress = 0;
        bool musicStarted = false;
        int musicChannel = -1;
    };

    bool init(bool refresh) {
        if (!LoadingLayer::init(refresh)) return false;
        auto* f = m_fields.self();
        auto size = CCDirector::get()->getWinSize();
        f->cover = CCLayerColor::create({0, 0, 0, 255}, size.width, size.height);
        f->cover->setID("gxlx-loading-cover");
        addChild(f->cover, 10000); // Hide normal loading content without disrupting GD/Geode hooks.
        auto logoPath = utils::string::pathToString(gxlx::resource("gxlx-logo.png"));
        f->logo = CCSprite::create(logoPath.c_str());
        if (f->logo) f->cover->addChild(f->logo);

        f->backGlow = CCLayerColor::create({130, 0, 17, 24});
        f->outerGlow = CCLayerColor::create({244, 8, 38, 48});
        f->frame = CCLayerColor::create({255, 39, 65, 255});
        f->track = CCLayerColor::create({41, 0, 5, 255});
        f->fill = CCLayerGradient::create({125, 0, 15, 255}, {255, 3, 24, 255}, {1, 0});
        f->fillGlow = CCLayerColor::create({255, 32, 49, 74});
        f->shine = CCLayerColor::create({255, 159, 166, 255});
        for (auto* node : {f->backGlow, f->outerGlow, f->frame, f->track, static_cast<CCLayerColor*>(f->fill), f->fillGlow, f->shine})
            f->cover->addChild(node);
        f->percent = CCLabelTTF::create("0%", "Arial", 24.f);
        if (f->percent) {
            f->percent->setColor({255, 37, 59});
            f->cover->addChild(f->percent);
        }
        updateGxLx(0.f);
        schedule(schedule_selector(GxLxLoadingLayer::updateGxLx));
        return true;
    }

    void onExit() override {
        auto* f = m_fields.self();
        if (f->musicStarted) {
            auto* engine = FMODAudioEngine::get();
            auto songPath = utils::string::pathToString(gxlx::resource("sevvend.mp3"));
            if (auto it = engine->m_channelIDToSoundPath.find(f->musicChannel);
                it != engine->m_channelIDToSoundPath.end() && it->second == songPath)
                engine->stopChannel(f->musicChannel);
        }
        LoadingLayer::onExit();
    }

    void updateGxLx(float) {
        auto* f = m_fields.self();
        if (!f->cover) return;
        auto size = CCDirector::get()->getWinSize();
        f->cover->setContentSize(size);
        if (f->logo) {
            auto content = f->logo->getContentSize();
            if (content.height > 0) {
                float extent = std::min(size.height * .26f, size.width * .30f);
                f->logo->setScale(extent / content.height);
                f->logo->setPosition({size.width * .5f, size.height * .68f});
            }
        }
        // The game/Geode slider is the only source of progress, never an independent timer.
        if (m_sliderBar && m_sliderGrooveXPos > 0.f) {
            float value = m_sliderBar->getTextureRect().size.width / m_sliderGrooveXPos;
            if (std::isfinite(value)) f->progress = std::max(f->progress, std::clamp(value, 0.f, 1.f));
        }
        if (!f->musicStarted && f->progress > .01f) {
            auto song = gxlx::resource("sevvend.mp3");
            if (std::filesystem::exists(song)) {
                f->musicStarted = true;
                f->musicChannel = FMODAudioEngine::get()->playEffect(utils::string::pathToString(song));
            }
        }
        const float width = std::min(size.width * .76f, 590.f);
        const float left = (size.width-width) * .5f;
        const float bottom = size.height * .43f;
        f->backGlow->setContentSize({width + 32, 40});
        f->backGlow->setPosition({left - 16, bottom - 14});
        f->outerGlow->setContentSize({width + 16, 24});
        f->outerGlow->setPosition({left - 8, bottom - 6});
        f->frame->setContentSize({width + 4, 14});
        f->frame->setPosition({left - 2, bottom - 1});
        f->track->setContentSize({width, 10});
        f->track->setPosition({left, bottom + 1});
        f->fill->setContentSize({width*f->progress, 10});
        f->fill->setPosition({left, bottom + 1});
        f->fillGlow->setContentSize({width*f->progress, 18});
        f->fillGlow->setPosition({left, bottom - 3});
        f->shine->setContentSize({width*f->progress, 1});
        f->shine->setPosition({left, bottom + 10});
        if (f->percent) {
            f->percent->setString(fmt::format("{}%", std::clamp(static_cast<int>(f->progress * 100.f), 0, 100)).c_str());
            f->percent->setPosition({left + 24, bottom + 38});
        }
    }
};
