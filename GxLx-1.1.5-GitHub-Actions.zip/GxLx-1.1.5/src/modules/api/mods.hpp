#pragma once
#include <functional.hpp>
#include <map>
#include <string>

namespace gxlx::api {
    geode::utils::StringMap<geode::Function<bool()>>& getCheats();
}
