// GxLx additions, 2026-11-08. EPL-2.0.
#include <modules/config/config.hpp>
#include <modules/gui/gui.hpp>
#include <modules/gui/components/toggle.hpp>
#include <modules/hack/hack.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PlayerObject.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/GJEffectManager.hpp>
#include <Geode/modify/HardStreak.hpp>
#include <Geode/binding/UILayer.hpp>
#include <algorithm>
#include <unordered_map>

namespace gxlx::gameplay {
    using namespace gxlx;
    bool enabled(const char* id) { return config::get<bool>(id, false); }

    class $hack(GxLxGameplay) {
        void init() override {
            auto cosmetic = gui::MenuTab::find("Cosmetic");
            for (auto const& [name, id] : std::initializer_list<std::pair<const char*, const char*>>{
                {"Force Don't Enter", "gxlx.dontenter"}, {"Force Don't Fade", "gxlx.dontfade"},
                {"Hide Attempts", "gxlx.hideattempts"}, {"Hide Pause Button", "gxlx.hidepausebutton"},
                {"No New Best Popup", "gxlx.nonewbest"}, {"No Force Glow", "gxlx.noforceglow"},
                {"No Rotation", "gxlx.norotation"}, {"No Pulse", "gxlx.nopulse"},
                {"No Wave Pulse", "gxlx.nowavepulse"}, {"No Wave Trail", "gxlx.nowavetrail"},
                {"Stable Pulse", "gxlx.stablepulse"}
            }) cosmetic->addToggle(name, id)->handleKeybinds();

            auto level = gui::MenuTab::find("tab.level");
            for (auto const& [name, id] : std::initializer_list<std::pair<const char*, const char*>>{
                {"Freeze Player", "gxlx.freezeplayer"}, {"Ignore ESC", "gxlx.ignoreesc"},
                {"No Hitbox", "gxlx.nohitbox"}, {"No Solids", "gxlx.nosolids"},
                {"No Spikes", "gxlx.nospikes"}, {"Everything Hurts", "gxlx.everythinghurts"},
                {"Force Visibility", "gxlx.forcevisibility"}
            }) level->addToggle(name, id)->handleKeybinds();
        }
        bool isCheating() const override {
            return enabled("gxlx.freezeplayer") || enabled("gxlx.nohitbox") ||
                enabled("gxlx.nosolids") || enabled("gxlx.nospikes") ||
                enabled("gxlx.forcevisibility") || enabled("gxlx.dontfade") || enabled("gxlx.dontenter");
        }
        const char* getId() const override { return "GxLx Gameplay Additions"; }
    };
    REGISTER_HACK(GxLxGameplay)

    class $modify(GxLxPlay, PlayLayer) {
        struct ObjectState { bool enter; bool fade; };
        struct Fields {
            std::unordered_map<GameObject*, ObjectState> originals;
            unsigned char attemptOpacity = 255;
            bool attemptsHidden = false;
            bool pauseHidden = false;
            bool pauseWasVisible = true;
            bool enter = false;
            bool fade = false;
        };
        void postUpdate(float dt) override {
            PlayLayer::postUpdate(dt);
            auto* f = m_fields.self();
            const bool hide = enabled("gxlx.hideattempts");
            if (m_attemptLabel) {
                if (hide && !f->attemptsHidden) f->attemptOpacity = m_attemptLabel->getOpacity();
                if (hide) m_attemptLabel->setOpacity(0);
                else if (f->attemptsHidden) m_attemptLabel->setOpacity(f->attemptOpacity);
            }
            f->attemptsHidden = hide;
            const bool pause = enabled("gxlx.hidepausebutton");
            if (m_uiLayer && m_uiLayer->m_pauseBtn) {
                auto* button = m_uiLayer->m_pauseBtn;
                if (pause && !f->pauseHidden) f->pauseWasVisible = button->isVisible();
                if (pause) button->setVisible(false);
                else if (f->pauseHidden) button->setVisible(f->pauseWasVisible);
            }
            f->pauseHidden = pause;

            bool enter = enabled("gxlx.dontenter"), fade = enabled("gxlx.dontfade");
            if ((enter != f->enter || fade != f->fade) && m_objects) {
                for (auto* obj : geode::cocos::CCArrayExt<GameObject*>(m_objects)) {
                    auto [it, added] = f->originals.try_emplace(obj, ObjectState{obj->m_isDontEnter, obj->m_isDontFade});
                    obj->m_isDontEnter = enter || it->second.enter;
                    obj->m_isDontFade = fade || it->second.fade;
                }
                f->enter = enter; f->fade = fade;
            }
        }
        void updateVisibility(float dt) override {
            PlayLayer::updateVisibility(dt);
            if (enabled("gxlx.forcevisibility") && m_objects) {
                for (auto* obj : geode::cocos::CCArrayExt<GameObject*>(m_objects)) {
                    if (!obj->m_isDisabled && !obj->m_isDisabled2) {
                        obj->setVisible(true);
                        obj->setOpacity(255);
                    }
                }
            }
        }
        void showNewBest(bool reward, int orbs, int diamonds, bool key, bool noRetry, bool noTitle) {
            if (!enabled("gxlx.nonewbest"))
                PlayLayer::showNewBest(reward, orbs, diamonds, key, noRetry, noTitle);
        }
        void keyBackClicked() override {
            if (!enabled("gxlx.ignoreesc")) PlayLayer::keyBackClicked();
        }
    };

    class $modify(GxLxPlayer, PlayerObject) {
        void update(float dt) override {
            if (utils::get<PlayLayer>() && enabled("gxlx.freezeplayer")) return;
            PlayerObject::update(dt);
        }
        void updateRotation(float dt) {
            if (enabled("gxlx.norotation")) { setRotation(0); return; }
            PlayerObject::updateRotation(dt);
        }
        void updatePlayerGlow() {
            const bool glow = m_hasGlow;
            if (enabled("gxlx.noforceglow")) m_hasGlow = false;
            PlayerObject::updatePlayerGlow();
            m_hasGlow = glow;
        }
    };

    class $modify(GxLxCollisions, GJBaseGameLayer) {
        void collisionCheckObjects(PlayerObject* player, gd::vector<GameObject*>* objects, int count, float dt) {
            const bool noAll = enabled("gxlx.nohitbox"), noSolid = enabled("gxlx.nosolids"),
                noSpike = enabled("gxlx.nospikes"), hurts = enabled("gxlx.everythinghurts");
            if (!objects || (!noAll && !noSolid && !noSpike && !hurts))
                return GJBaseGameLayer::collisionCheckObjects(player, objects, count, dt);
            gd::vector<GameObject*> filtered;
            count = std::clamp(count, 0, static_cast<int>(objects->size()));
            filtered.reserve(count);
            for (int i = 0; i < count; ++i) {
                auto* obj = (*objects)[i];
                if (!obj) continue;
                const auto type = obj->m_objectType;
                const bool solid = type == GameObjectType::Solid || type == GameObjectType::Slope;
                const bool hazard = type == GameObjectType::Hazard || type == GameObjectType::AnimatedHazard;
                if (((noAll || noSolid) && solid) || ((noAll || noSpike) && hazard)) continue;
                if (hurts && !obj->m_isDisabled && !obj->m_isDisabled2 && obj != player &&
                    player->getObjectRect(1.f,1.f).intersectsRect(obj->getObjectRect(1.f,1.f)))
                    destroyPlayer(player, obj);
                filtered.push_back(obj);
            }
            GJBaseGameLayer::collisionCheckObjects(player, &filtered, static_cast<int>(filtered.size()), dt);
        }
    };

    class $modify(GxLxPulse, GJEffectManager) {
        cocos2d::ccColor3B colorForPulseEffect(cocos2d::ccColor3B const& color, PulseEffectAction* action) {
            if (enabled("gxlx.nopulse")) return color;
            return GJEffectManager::colorForPulseEffect(color, action);
        }
    };

    class $modify(GxLxWave, HardStreak) {
        void updateStroke(float dt) {
            if (enabled("gxlx.nowavetrail")) { clear(); return; }
            const auto pulse = m_pulseSize;
            if (enabled("gxlx.nowavepulse") || enabled("gxlx.stablepulse")) m_pulseSize = 1.f;
            HardStreak::updateStroke(dt);
            m_pulseSize = pulse;
        }
    };
}
