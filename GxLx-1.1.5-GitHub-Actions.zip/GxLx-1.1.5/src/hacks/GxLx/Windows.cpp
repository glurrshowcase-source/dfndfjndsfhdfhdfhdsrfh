// GxLx additions, 2026-11-08. EPL-2.0.
#include <modules/config/config.hpp>
#include <modules/gui/gui.hpp>
#include <modules/gui/components/button.hpp>
#include <modules/gui/components/combo.hpp>
#include <modules/gui/components/input-int.hpp>
#include <modules/gui/components/toggle.hpp>
#include <modules/hack/hack.hpp>
#include <modules/labels/variables.hpp>
#include <Geode/binding/FMODAudioEngine.hpp>
#include <Geode/binding/OptionsLayer.hpp>
#include <Windows.h>
#include <chrono>
#include <algorithm>

namespace gxlx::desktop {
    using namespace gxlx;
    struct GameOption { const char* name; const char* id; const char* variable; };
    constexpr GameOption options[] = {
        {"Smooth Fix", "gxlx.smoothfix", GameVar::SmoothFix},
        {"Force Smooth Fix", "gxlx.forcesmoothfix", GameVar::ForceSmoothFix},
        {"Low Detail", "gxlx.lowdetail", GameVar::LowDetail},
        {"Mini Cube Icon", "gxlx.miniicon", GameVar::DefaultMiniIcon},
        {"Show Percentage", "gxlx.percentage", GameVar::ShowPercentage}
    };
    class $hack(GxLxWindows) {
        bool muted = false;
        bool wasMute = false;
        bool resizeChanged = false;
        bool deafenSent = false;
        LONG_PTR oldStyle = 0;
        std::chrono::steady_clock::time_point lastFrame = std::chrono::steady_clock::now();
        std::chrono::steady_clock::time_point sessionStart = std::chrono::steady_clock::now();

        void init() override {
            auto tab = gui::MenuTab::find("Display");
            for (auto const& op : options) {
                tab->addToggle(op.name, op.id)->callback([key=op.variable](bool on) {
                    utils::get<GameManager>()->setGameVariable(key, on);
                });
            }
            tab->addToggle("Windowed", "gxlx.windowed")->callback([](bool on) {
                auto* gm = utils::get<GameManager>();
                gm->setGameVariable(GameVar::WindowedMode, on);
                cocos2d::CCEGLView::sharedOpenGLView()->toggleFullScreen(!on,
                    gm->getGameVariable(GameVar::BorderlessFullscreen), false);
            });
            config::setIfEmpty("gxlx.width",1280); config::setIfEmpty("gxlx.height",720);
            tab->addInputInt("Width", "gxlx.width",640,7680);
            tab->addInputInt("Height", "gxlx.height",360,4320);
            tab->addButton("Set Window Size")->callback([] {
                auto hwnd=WindowFromDC(wglGetCurrentDC());
                if (!hwnd || !utils::get<GameManager>()->getGameVariable(GameVar::WindowedMode)) return;
                RECT r{0,0,std::clamp(config::get<int>("gxlx.width",1280),640,7680),
                    std::clamp(config::get<int>("gxlx.height",720),360,4320)};
                AdjustWindowRectEx(&r,static_cast<DWORD>(GetWindowLongPtr(hwnd,GWL_STYLE)),FALSE,
                    static_cast<DWORD>(GetWindowLongPtr(hwnd,GWL_EXSTYLE)));
                SetWindowPos(hwnd,nullptr,0,0,r.right-r.left,r.bottom-r.top,SWP_NOMOVE|SWP_NOZORDER);
            });
            tab->addButton("Screenshot (PNG)")->callback([] {
                auto* director=cocos2d::CCDirector::sharedDirector();
                auto size=director->getWinSize();
                auto* texture=cocos2d::CCRenderTexture::create(static_cast<int>(size.width),static_cast<int>(size.height));
                if (!texture || !director->getRunningScene()) return;
                texture->begin(); director->getRunningScene()->visit(); texture->end();
                const auto stamp=std::chrono::system_clock::now().time_since_epoch().count();
                auto path=geode::Mod::get()->getSaveDir()/fmt::format("GxLx-{}.png",stamp);
                auto* image=texture->newCCImage();
                const bool ok=image && image->saveToFile(path.string().c_str(),false);
                if (image) image->release();
                geode::Notification::create(ok ? "Saved PNG in GxLx save folder" : "Screenshot failed",
                    ok ? geode::NotificationIcon::Success : geode::NotificationIcon::Error)->show();
            });
            auto global = gui::MenuTab::find("tab.global");
            global->addToggle("Free Window Resize", "gxlx.resize")->handleKeybinds();
            global->addToggle("Mute on Unfocus", "gxlx.muteunfocus")->handleKeybinds();
            config::setIfEmpty("gxlx.deafenpercent",50);
            config::setIfEmpty("gxlx.deafenkey",124);
            global->addToggle("Auto Deafen", "gxlx.autodeafen")->setDescription(
                "Sends a Discord global deafen hotkey when the chosen percentage is reached, and again after death or exit. "
                "Bind F13 in Discord first (Windows key code 124); this cannot read Discord's current mute state."
            )->addOptions([](auto* opt) {
                opt->addInputInt("Deafen at %", "gxlx.deafenpercent",0,100);
                opt->addInputInt("Windows key code (124 = F13)", "gxlx.deafenkey",1,254);
            });
            global->addInputInt("Unfocused FPS (0 = unchanged)", "gxlx.unfocusedfps",0,360);
            global->addCombo("Thread Priority", "gxlx.threadpriority",{"Normal","Above normal","Below normal"},0)->callback([](int v) {
                SetThreadPriority(GetCurrentThread(),v==1 ? THREAD_PRIORITY_ABOVE_NORMAL : v==2 ? THREAD_PRIORITY_BELOW_NORMAL : THREAD_PRIORITY_NORMAL);
            });
        }
        void lateInit() override {
            auto* gm=utils::get<GameManager>();
            for (const auto& op : options) config::set(op.id,gm->getGameVariable(op.variable));
            config::set("gxlx.windowed",gm->getGameVariable(GameVar::WindowedMode));
        }
        void update() override {
            auto seconds=std::chrono::duration_cast<std::chrono::seconds>(std::chrono::steady_clock::now()-sessionStart).count();
            labels::VariableManager::get().setVariable("gxlxSession",fmt::format("{}:{:02}:{:02}",seconds/3600,(seconds/60)%60,seconds%60));
            const auto hwnd=WindowFromDC(wglGetCurrentDC());
            if (!hwnd) return;
            auto* pl=utils::get<PlayLayer>();
            const bool shouldDeafen=config::get<bool>("gxlx.autodeafen",false) && pl && pl->m_player1 &&
                !pl->m_player1->m_isDead && !pl->m_hasCompletedLevel &&
                pl->getCurrentPercent() >= config::get<int>("gxlx.deafenpercent",50);
            if(shouldDeafen != deafenSent) {
                INPUT inputs[2]{};
                inputs[0].type=inputs[1].type=INPUT_KEYBOARD;
                inputs[0].ki.wVk=inputs[1].ki.wVk=static_cast<WORD>(std::clamp(config::get<int>("gxlx.deafenkey",124),1,254));
                inputs[1].ki.dwFlags=KEYEVENTF_KEYUP;
                if(SendInput(2,inputs,sizeof(INPUT))==2) deafenSent=shouldDeafen;
            }
            bool resize=config::get<bool>("gxlx.resize",false) && utils::get<GameManager>()->getGameVariable(GameVar::WindowedMode);
            if (resize && !resizeChanged) {
                oldStyle=GetWindowLongPtr(hwnd,GWL_STYLE);
                SetWindowLongPtr(hwnd,GWL_STYLE,oldStyle|WS_THICKFRAME|WS_MAXIMIZEBOX);
                SetWindowPos(hwnd,nullptr,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOZORDER|SWP_FRAMECHANGED);
            } else if (!resize && resizeChanged) {
                auto current=GetWindowLongPtr(hwnd,GWL_STYLE);
                SetWindowLongPtr(hwnd,GWL_STYLE,current & ~((WS_THICKFRAME|WS_MAXIMIZEBOX) & ~oldStyle));
                SetWindowPos(hwnd,nullptr,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOZORDER|SWP_FRAMECHANGED);
            }
            resizeChanged=resize;
            const bool unfocused=GetForegroundWindow()!=hwnd;
            const bool shouldMute=unfocused && config::get<bool>("gxlx.muteunfocus",false);
            if (shouldMute!=muted) {
                if (auto* audio=utils::get<FMODAudioEngine>(); audio && audio->m_system) {
                    FMOD::ChannelGroup* group=nullptr;
                    if (audio->m_system->getMasterChannelGroup(&group)==FMOD_OK && group) {
                        if (shouldMute) group->getMute(&wasMute);
                        group->setMute(shouldMute || wasMute);
                        muted=shouldMute;
                    }
                }
            }
            auto now=std::chrono::steady_clock::now();
            int cap=config::get<int>("gxlx.unfocusedfps",0);
            if (unfocused && cap>0) {
                const double elapsed=std::chrono::duration<double,std::milli>(now-lastFrame).count();
                if (const double remain=1000.0/std::clamp(cap,1,360)-elapsed; remain>0)
                    Sleep(static_cast<DWORD>(remain));
            }
            lastFrame=std::chrono::steady_clock::now();
        }
        const char* getId() const override { return "GxLx Windows Controls"; }
    };
    REGISTER_HACK(GxLxWindows)
}
