// GxLx additions, 2026-11-08. EPL-2.0.
#include <modules/config/config.hpp>
#include <modules/gui/gui.hpp>
#include <modules/gui/color.hpp>
#include <modules/gui/components/button.hpp>
#include <modules/gui/components/combo.hpp>
#include <modules/gui/components/input-float.hpp>
#include <modules/gui/components/toggle.hpp>
#include <modules/hack/hack.hpp>
#include <Geode/modify/PlayerObject.hpp>
#include <Geode/modify/RingObject.hpp>
#include <chrono>
#include <cmath>
#include <random>

namespace gxlx::icons {
    using namespace gxlx;
    using namespace cocos2d;
    constexpr const char* channelNames[] = {"Colour 1", "Colour 2", "Glow", "Trail", "Wave", "Particles"};

    ccColor3B rainbow(float phase) {
        const float h = (phase - std::floor(phase)) * 6.f;
        const float x = 1.f - std::abs(std::fmod(h, 2.f) - 1.f);
        float r=0,g=0,b=0;
        if(h<1){r=1;g=x;} else if(h<2){r=x;g=1;} else if(h<3){g=1;b=x;}
        else if(h<4){g=x;b=1;} else if(h<5){r=x;b=1;} else{r=1;b=x;}
        return {static_cast<GLubyte>(r*255),static_cast<GLubyte>(g*255),static_cast<GLubyte>(b*255)};
    }

    class $hack(GxLxIcons) {
        void init() override {
            auto tab=gui::MenuTab::find("Icons");
            config::setIfEmpty("gxlx.icons.speed",1.f);
            for (int player=1;player<=2;++player) {
                const auto prefix=fmt::format("gxlx.icons.p{}",player);
                tab->addToggle(fmt::format("Player {}",player),prefix)->addOptions([prefix](auto* opt) {
                    for(int i=0;i<6;++i) {
                        auto id=fmt::format("{}.{}",prefix,i);
                        opt->addCombo(channelNames[i],id,{"No Effect","Custom Colour","Rainbow"},0);
                        config::setIfEmpty(id+".color",gui::Color(235,25,55));
                        opt->addColorComponent(std::string(channelNames[i])+" colour",id+".color");
                    }
                });
            }
            tab->addInputFloat("Cycle Speed", "gxlx.icons.speed",0.01f,10.f,"%.2fx");
            tab->addToggle("Same Dual Colour", "gxlx.icons.samedual");
            tab->addToggle("Inversed Trail", "gxlx.icons.inversed");
            tab->addToggle("No Orb Ring", "gxlx.noorbring")->handleKeybinds();
            tab->addButton("Icon Randomiser")->callback([] {
                auto* gm=utils::get<GameManager>();
                static std::mt19937 rng(std::random_device{}());
                auto pick=[&](IconType type) { return std::uniform_int_distribution<int>(1,std::max(1,gm->countForType(type)))(rng); };
                gm->setPlayerFrame(pick(IconType::Cube)); gm->setPlayerShip(pick(IconType::Ship));
                gm->setPlayerBall(pick(IconType::Ball)); gm->setPlayerBird(pick(IconType::Ufo));
                gm->setPlayerDart(pick(IconType::Wave)); gm->setPlayerRobot(pick(IconType::Robot));
                gm->setPlayerSpider(pick(IconType::Spider)); gm->setPlayerSwing(pick(IconType::Swing));
                gm->setPlayerJetpack(pick(IconType::Jetpack));
                geode::Notification::create("Icons randomised. Re-enter the level to apply.",geode::NotificationIcon::Success)->show();
            });
        }
        const char* getId() const override { return "GxLx Icon Effects"; }
    };
    REGISTER_HACK(GxLxIcons)

    class $modify(GxLxIconPlayer, PlayerObject) {
        struct ParticleState { CCParticleSystemQuad* particle; ccColor4F start; ccColor4F end; };
        struct Fields {
            bool modified=false;
            ccColor3B main{},second{},glow{},trail{},wave{};
            std::vector<ParticleState> particles;
        };
        void restore() {
            auto* f=m_fields.self();
            if(!f->modified) return;
            setColor(f->main); setSecondColor(f->second); m_glowColor=f->glow; updateGlowColor();
            if(m_regularTrail) m_regularTrail->setColor(f->trail);
            if(m_waveTrail) m_waveTrail->setColor(f->wave);
            for(auto const& p:f->particles) { p.particle->setStartColor(p.start); p.particle->setEndColor(p.end); }
            f->particles.clear(); f->modified=false;
        }
        void update(float dt) override {
            restore();
            PlayerObject::update(dt);
            auto* layer=utils::get<PlayLayer>();
            if(!layer) return;
            bool p2=this==layer->m_player2;
            auto prefix=fmt::format("gxlx.icons.p{}",p2 && !config::get<bool>("gxlx.icons.samedual",false)?2:1);
            bool inverse=config::get<bool>("gxlx.icons.inversed",false);
            if(!config::get<bool>(prefix,false) && !inverse) return;
            auto* f=m_fields.self();
            f->main=getColor(); f->second=m_playerColor2; f->glow=m_glowColor;
            if(m_regularTrail) f->trail=m_regularTrail->getColor();
            if(m_waveTrail) f->wave=m_waveTrail->getColor();
            f->modified=true;
            if(inverse && m_regularTrail) m_regularTrail->setColor(m_playerColor2);
            if(!config::get<bool>(prefix,false)) return;
            static const auto start=std::chrono::steady_clock::now();
            const float phase=std::chrono::duration<float>(std::chrono::steady_clock::now()-start).count()*config::get<float>("gxlx.icons.speed",1.f)*.1f;
            for(int i=0;i<6;++i) {
                auto id=fmt::format("{}.{}",prefix,i); int mode=config::get<int>(id,0);
                if(mode==0) continue;
                auto color=mode==2?rainbow(phase+i*.06f):config::get<gui::Color>(id+".color",gui::Color(235,25,55)).toCCColor3B();
                switch(i) {
                    case 0: setColor(color); break;
                    case 1: setSecondColor(color); break;
                    case 2: m_glowColor=color; updateGlowColor(); break;
                    case 3: if(m_regularTrail) m_regularTrail->setColor(color); break;
                    case 4: if(m_waveTrail) m_waveTrail->setColor(color); break;
                    case 5:
                        for(auto* particle:{m_playerGroundParticles,m_trailingParticles,m_shipClickParticles,m_vehicleGroundParticles,m_ufoClickParticles,m_robotBurstParticles,m_dashParticles}) {
                            if(!particle) continue;
                            f->particles.push_back({particle,particle->getStartColor(),particle->getEndColor()});
                            particle->setStartColor({color.r/255.f,color.g/255.f,color.b/255.f,1.f});
                            particle->setEndColor({color.r/255.f,color.g/255.f,color.b/255.f,0.f});
                        }
                        break;
                }
            }
        }
    };
    class $modify(GxLxOrb, RingObject) {
        void spawnCircle() {
            if(!config::get<bool>("gxlx.noorbring",false)) RingObject::spawnCircle();
        }
    };
}
