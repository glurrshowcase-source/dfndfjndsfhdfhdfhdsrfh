#include <Geode/binding/ButtonSprite.hpp>
#include <Geode/loader/Mod.hpp>
#include <Geode/loader/SettingV3.hpp>
#include <Geode/ui/Popup.hpp>
#include <modules/gui/native/components/KeybindComponent.hpp>
#include <modules/gui/theming/manager.hpp>

using namespace geode::prelude;

class CustomKeybindSetting : public SettingV3 {
public:
    static Result<std::shared_ptr<SettingV3>> parse(std::string const& key, std::string const& modID, matjson::Value const& json) {
        auto res = std::make_shared<CustomKeybindSetting>();
        auto root = checkJson(json, "CustomKeybindSetting");

        res->init(key, modID, root);
        res->parseNameAndDescription(root);
        res->parseEnableIf(root);

        root.checkUnknownKeys();
        return root.ok(std::static_pointer_cast<SettingV3>(res));
    }

    bool load(matjson::Value const& json) override { return true; }
    bool save(matjson::Value& json) const override { return true; }
    bool isDefaultValue() const override { return true; }

    void reset() override {}

    SettingNodeV3* createNode(float width) override;
};

class CustomKeybindSettingNode : public SettingNodeV3 {
protected:
    bool init(const std::shared_ptr<CustomKeybindSetting>& setting, float width) {
        if (!SettingNodeV3::init(setting, width))
            return false;

        using namespace gxlx;
        using namespace gxlx::gui;
        auto keybindComponent = Component::find(keybinds::Manager::get()->getMenuKeybindUID());
        auto node = gui::native::KeybindComponentNode::create(keybindComponent, 240);
        node->getChildByID("label"_spr)->setVisible(false);

        this->getButtonMenu()->addChildAtPosition(node, Anchor::Center);
        this->getButtonMenu()->setContentWidth(240);
        this->getButtonMenu()->updateLayout();

        this->updateState(nullptr);

        return true;
    }

    void onCommit() override {}

    void onResetToDefault() override {}

public:
    static CustomKeybindSettingNode* create(const std::shared_ptr<CustomKeybindSetting>& setting, float width) {
        auto ret = new CustomKeybindSettingNode;
        if (ret->init(setting, width)) {
            ret->autorelease();
            return ret;
        }
        delete ret;
        return nullptr;
    }

    bool hasUncommittedChanges() const override { return false; }
    bool hasNonDefaultValue() const override { return false; }

    std::shared_ptr<CustomKeybindSetting> getSetting() const {
        return std::static_pointer_cast<CustomKeybindSetting>(SettingNodeV3::getSetting());
    }
};

SettingNodeV3* CustomKeybindSetting::createNode(float width) {
    return CustomKeybindSettingNode::create(
        std::static_pointer_cast<CustomKeybindSetting>(shared_from_this()),
        width
    );
}

$execute {
    (void) Mod::get()->registerCustomSettingType("keybind", &CustomKeybindSetting::parse);
}
