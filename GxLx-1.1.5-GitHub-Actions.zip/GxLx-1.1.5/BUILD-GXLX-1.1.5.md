# GxLx 1.1.5 – build and feature notes

Build target: Geometry Dash 2.2081 / Geode SDK 5.11.2 / Windows x64.

## New features
- Ten physical presses of the configured menu hotkey in a rolling ten-second window start a Windows Media Foundation player over the game (33-second 10clicks.mp4). Menu hotkeys are suppressed while it plays. Playback ends automatically, with a forty-second failsafe. Closing the game still exits.
- Type G X L X (within three seconds between characters) to download level ID 151673976 and directly enter PlayLayer. Does not displace an existing level download delegate.
- Black startup cover with red neon bar using actual Geode loading bar progress, with sevvend.mp3 playback while loading.
- Tabbed menu window width and maximum height reduced 25%; panel/sidebar and popups also scaled down.
- Live searchable hack names/IDs in GxLx menu header (Tabbed layout).

## Known limitations
- Windows video uses MFPlay's native child window. Fullscreen support depends on Windows/graphics/window mode. If the codec or engine fails to initialize, playback does not start.
- Geode's loader can display resource progress differently from GD's original slider; the bar follows available native progress data.
- This build has not been runtime-tested on a local GD installation.
- The MP4 was re-encoded to 1280x720 and the MP3 to 96 kb/s to keep the single-file GitHub upload under 25 MiB.
- EPL-2.0 source attribution, dependency names and third-party license files remain intact.
