# GxLx Support

**Developer:** GxLx

**Channel:** [@DJakDoki](https://www.youtube.com/@DJakDoki)

For support, provide your Geode and GD versions plus relevant crash logs.
