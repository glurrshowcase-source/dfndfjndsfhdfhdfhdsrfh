param([int]$Jobs = 4)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
function Run([string]$Program, [string[]]$Arguments) {
    & $Program @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Program failed with exit code $LASTEXITCODE" }
}
if (-not $env:GEODE_SDK -or -not (Test-Path "$env:GEODE_SDK/VERSION")) {
    throw 'Set GEODE_SDK to the Geode 5.11.2 SDK directory first.'
}
if ((Get-Content "$env:GEODE_SDK/VERSION" -Raw).Trim() -ne '5.11.2') {
    throw 'This project targets Geode SDK 5.11.2 and GD 2.2081.'
}
$bindingsPath = Join-Path $PSScriptRoot 'vendor/bindings'
if (-not (Test-Path "$bindingsPath/.git")) {
    Run git @('clone', 'https://github.com/geode-sdk/bindings.git', $bindingsPath)
}
Run git @('-C', $bindingsPath, 'checkout', '3e65294e5b68f0124cde08505b9ecbeb2e3d990b')
$env:GEODE_BINDINGS_REPO_PATH = $bindingsPath
Run cmake @('-S','.', '-B','build-windows', '-G','Ninja', '-DCMAKE_BUILD_TYPE=Release',
    '-DCMAKE_C_COMPILER=clang-cl', '-DCMAKE_CXX_COMPILER=clang-cl',
    '-DGEODE_TARGET_PLATFORM=Win64', '-DGXLX_ENABLE_UNITY_BUILD=ON',
    '-DSKIP_BUILDING_CODEGEN=OFF', '-DCMAKE_POLICY_VERSION_MINIMUM=3.5')
Run cmake @('--build','build-windows','--parallel', [string]$Jobs)
Write-Host 'Built build-windows/gxlx.menu.geode. Copy it into Geometry Dash/geode/mods.'
