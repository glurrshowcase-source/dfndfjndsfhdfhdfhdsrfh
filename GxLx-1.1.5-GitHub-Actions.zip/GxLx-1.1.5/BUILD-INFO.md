# Informacje o kompilacji GxLx 1.1.1

Data: 2026-11-08. Cel: Windows x64 (PE AMD64), GD 2.2081, Geode 5.11.2.
Tryb: Release. Kompilator: Clang 19.1.1, linker lld-link 19, CMake 4.4.4.
Kompilacja krzyżowa z Linuksa z Windows SDK/MSVC CRT. Geode CLI 3.9.0.
Geode.lib pochodzi z oficjalnego archiwum geode-v5.11.2-win.zip.
Codegen: zgodna z Geode 5 wersja z istniejącego toolchainu, generująca nagłówki
z przypiętego repo bindings. Skrypt Windows buduje codegen z tych źródeł.

Baza Eclipse: d45f2f40fa7ec2492ad399027ca7151e5ee09d8f (v1.9.4).
Geode SDK: 3909856e8714b503945d5cea12ba1bddf5d5b1b0 (v5.11.2).
Bindings: 3e65294e5b68f0124cde08505b9ecbeb2e3d990b.

## Walidacja

- Windows DLL zlinkowana bez błędów; importy Geode.dll, bibliotek GD i standardowego runtime Windows.
- Geode CLI poprawnie zbudował sprite sheety i paczkę.
- JSON poprawny: gxlx.menu, Windows GD 2.2081, minimum Geode 5.11.2.
- Test integralności CRC archiwum ZIP/.geode bez błędów.
- Renderer ImGui: obrazy 1600 × 1000 i 49 klatek animacji; wspólny kod transformacji/przycinania używany przez mod. Sprawdzono stan otwarty, klatkę obrotu oraz całkowicie pusty stan zamknięty.
- Natywny test presentation-check: płynne odwracanie kierunku, pozycja końcowa wszystkich paneli, granice parametrów, przycinanie trójkątów przed obrotem.
- PNG i MP3 w paczce są bajtowo zgodne z dostarczonymi plikami. MP3: 48 kHz stereo, 1,872 s.
- Metadata zawierają wyłącznie ustawienie menu-keybind; nie ma odczytów usuniętych ustawień przez API Geode.
- git diff --check bez błędów formatowania.
- Nie uruchomiono GD na Windows; nie sprawdzono zachowania hooków ani interakcji z innymi modami w grze.
- Skrypt PowerShell udostępniono jako sposób odtworzenia; nie uruchomiono go na Windows.

## Zakres poprawki 1.1.1

Usunięto klasę CocosRenderer, wariant RendererType::Cocos2d, alternatywne panele, popupy i ustawienia stylu. Pozostałe współdzielone kontrolki Geode/keybinda i etykiety gry przeniesiono do gui/native. Silnik menu i odczyt motywu wybierają zawsze ImGui; stare wartości renderer=1 nie są już odczytywane jako przełącznik. Migracja normalizuje stary wpis bez zmiany menu.toggleKey.

## Zależności źródłowe użyte przy kompilacji

| Pakiet | Commit |
|---|---|
| advancedlabel | `e9e16495801d46d3ef4cd102a09f3802add3e70c` |
| arc | `1fe91a6c890f3d0269151797c8561b2d6b4c08ed` |
| asp2 | `ecea33bad2d9804054888bbd12db9573b33aaebe` |
| discord-presence | `3b50b0854ec24f9b2d4cc8e28f9145f276bb998e` |
| fmt | `5ac44cd1282f12947d25f439b59c5e55944cdb04` |
| gd-imgui-cocos | `6383c75f7c3ec1ef63d24e0bc757dd5d4d326f18` |
| gdr-converter | `71104a9e0ae9bee19f3fc4b784303fc2929eab9d` |
| glaze | `459946d325c497c274fa59d666bd7cb6e2dd7ad0` |
| imgui | `8cf1bfc66d88ef84cf312865ed81bf17d6622c34` |
| json | `6330ad4d63d168c861e0a1b9d4127cdbd6807ad9` |
| msgpack-for-matjson | `12edd5a3c8eb1afa409669020517dac1e4bc0f96` |
| nontype_functional | `6d1d08cb447c038e3e56812dd362e61abc92933a` |
| result | `b17911426ced3ca519d9a338aea76053be6fc4f1` |
| rift | `e8d2bbafc2f4478dac35070bb19e4c8cb88bbc46` |
| rock | `6a2d29ea1fae8b4a5e8fa5f3517bbd92c577bacc` |
| sinaps | `7d2f7b13e0946ddb7ae3de1ac4ae3e5ddb893bcf` |
| tuliphook | `62ef839ee205d6943361c0902d08224acab32660` |
| zydis | `ae12a099a1323d1535881b50b5afe72cc0894afa` |
