// GxLx additions, 2026-11-08. EPL-2.0.
#include <modules/config/config.hpp>
#include <modules/gui/gui.hpp>
#include <modules/gui/components/button.hpp>
#include <modules/gui/components/input-float.hpp>
#include <modules/gui/components/input-int.hpp>
#include <modules/gui/components/toggle.hpp>
#include <modules/hack/hack.hpp>
#include <Geode/binding/EditorUI.hpp>
#include <Geode/modify/LevelEditorLayer.hpp>

namespace gxlx::creator {
    using namespace eclipse;
    EditorUI* selection() {
        auto* layer=utils::get<LevelEditorLayer>();
        auto* ui=layer?layer->m_editorUI:nullptr;
        if(!ui || !ui->getSelectedObjects() || !ui->getSelectedObjects()->count()) {
            geode::Notification::create("Select objects in the editor first",geode::NotificationIcon::Info)->show();
            return nullptr;
        }
        return ui;
    }
    cocos2d::CCPoint center(cocos2d::CCArray* objects) {
        cocos2d::CCPoint value{0,0};
        for(auto* obj:geode::cocos::CCArrayExt<GameObject*>(objects)) value+=obj->getPosition();
        return value/static_cast<float>(objects->count());
    }
    class $hack(GxLxCreator) {
        void init() override {
            auto tab=gui::MenuTab::find("tab.creator");
            [](auto* opt) {
                opt->addLabel("Absolute Position");
                opt->addInputFloat("X", "gxlx.position.x",-10000000.f,10000000.f,"%.2f");
                opt->addInputFloat("Y", "gxlx.position.y",-10000000.f,10000000.f,"%.2f");
                opt->addButton("Read selection position")->callback([] {
                    if(auto* ui=selection()) {
                        auto point=center(ui->getSelectedObjects());
                        config::set("gxlx.position.x",point.x); config::set("gxlx.position.y",point.y);
                    }
                });
                opt->addButton("Apply absolute position")->callback([] {
                    if(auto* ui=selection()) {
                        auto* objects=ui->getSelectedObjects();
                        const auto delta=cocos2d::CCPoint{config::get<float>("gxlx.position.x",0),config::get<float>("gxlx.position.y",0)}-center(objects);
                        ui->createUndoObject(UndoCommand::Transform,true);
                        for(auto* obj:geode::cocos::CCArrayExt<GameObject*>(objects)) ui->moveObject(obj,delta);
                        ui->updateObjectInfoLabel();
                    }
                });
            }(tab);
            config::setIfEmpty("gxlx.scale.x",1.f); config::setIfEmpty("gxlx.scale.y",1.f);
            [](auto* opt) {
                opt->addLabel("Absolute Scaling / Scale Snap Bypass");
                opt->addInputFloat("Scale X", "gxlx.scale.x",.001f,1000.f,"%.3f");
                opt->addInputFloat("Scale Y", "gxlx.scale.y",.001f,1000.f,"%.3f");
                opt->addButton("Apply absolute scale")->callback([] {
                    if(auto* ui=selection()) {
                        ui->createUndoObject(UndoCommand::Transform,true);
                        for(auto* obj:geode::cocos::CCArrayExt<GameObject*>(ui->getSelectedObjects())) {
                            obj->updateCustomScaleX(std::clamp(config::get<float>("gxlx.scale.x",1),.001f,1000.f));
                            obj->updateCustomScaleY(std::clamp(config::get<float>("gxlx.scale.y",1),.001f,1000.f));
                        }
                        ui->updateObjectInfoLabel();
                    }
                });
            }(tab);
            [](auto* opt) {
                opt->addLabel("Rotation Hack");
                opt->addInputFloat("Degrees", "gxlx.rotation.degrees",-36000.f,36000.f,"%.2f");
                opt->addButton("Rotate selection")->callback([] {
                    if(auto* ui=selection()) {
                        auto* objects=ui->getSelectedObjects();
                        ui->createUndoObject(UndoCommand::Transform,true);
                        ui->rotateObjects(objects,config::get<float>("gxlx.rotation.degrees",0),center(objects));
                        ui->updateObjectInfoLabel();
                    }
                });
            }(tab);
            config::setIfEmpty("gxlx.zoom",1.f);
            tab->addInputFloat("Zoom Bypass / Playtest Zoom", "gxlx.zoom",.01f,100.f,"%.2fx")->callback([](float zoom) {
                if(auto* layer=utils::get<LevelEditorLayer>(); layer && layer->m_editorUI)
                    layer->m_editorUI->updateZoom(std::clamp(zoom,.01f,100.f));
            });
            tab->addToggle("No Editor Trail", "gxlx.noeditortrail")->handleKeybinds()->callback([](bool on) {
                utils::get<GameManager>()->setGameVariable(GameVar::HidePlayerPath,on);
            });
            [](auto* opt) {
                opt->addLabel("Z Order Bypass");
                opt->addInputInt("Z Order", "gxlx.zorder.value",-32768,32767);
                opt->addButton("Apply Z Order")->callback([] {
                    if(auto* ui=selection()) {
                        ui->createUndoObject(UndoCommand::Transform,true);
                        int order=std::clamp(config::get<int>("gxlx.zorder.value",0),-32768,32767);
                        for(auto* obj:geode::cocos::CCArrayExt<GameObject*>(ui->getSelectedObjects())) {
                            obj->m_zOrder=order; obj->setZOrder(order);
                        }
                        ui->updateObjectInfoLabel();
                    }
                });
            }(tab);
        }
        const char* getId() const override { return "GxLx Creator Tools"; }
    };
    REGISTER_HACK(GxLxCreator)
}
