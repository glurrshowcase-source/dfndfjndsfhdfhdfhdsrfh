#include <Geode/loader/Setting.hpp>
#include <modules/gxlx/branding.hpp>
#include <Geode/modify/CCScheduler.hpp>
#include <Geode/modify/GameManager.hpp>
#include <Geode/modify/MenuLayer.hpp>

#include <imgui-cocos.hpp>
#include <modules/config/config.hpp>
#include <modules/hack/hack.hpp>
#include <modules/keybinds/manager.hpp>

#include <modules/gui/float-button.hpp>
#include <modules/gui/blur/blur.hpp>

#include <AdvancedLabel.hpp>
#include <modules/gui/theming/manager.hpp>

#include <modules/i18n/translations.hpp>

#include <modules/gui/components/button.hpp>
#include <modules/gui/components/combo.hpp>
#include <modules/gui/components/input-float.hpp>
#include <modules/gui/components/input-text.hpp>
#include <modules/gui/components/label.hpp>
#include <modules/gui/components/toggle.hpp>
#include <modules/gui/imgui/animation/easing.hpp>

using namespace eclipse;

static bool s_isInitialized = false;

static void toggleMenu(keybinds::KeyEvent evt = {}) {
    gui::Engine::get().toggle();
    gxlx::playToggleSound();
    config::save();
}

class $modify(ClearCacheGMHook, GameManager) {
    void reloadAllStep5() {
        GameManager::reloadAllStep5();
        utils::purgeAllSingletons();
        gui::blur::cleanup();
        #ifdef ECLIPSE_USE_FLOATING_BUTTON
        gui::FloatingButton::get()->reloadSprite();
        #endif
    }
};

class $modify(EclipseButtonMLHook, MenuLayer) {
    bool init() override {
        if (!MenuLayer::init()) return false;

        if (s_isInitialized) return true;

        // Compile blur shader
        gui::blur::init();

        // Initialize the GUI engine.
        gui::Engine::get().init();

        #ifdef ECLIPSE_USE_FLOATING_BUTTON
        // This will create the floating button and keep it across scenes
        gui::FloatingButton::get()->setCallback([]{ toggleMenu(); });
        #endif

        // Register the keybind
        auto& key = keybinds::Manager::get()->registerKeybind("menu.toggle", "Toggle UI", toggleMenu);
        config::setIfEmpty<keybinds::KeybindProps>("menu.toggleKey", keybinds::Keys::Tab);
        key.setKey(config::get<keybinds::KeybindProps>("menu.toggleKey", keybinds::Keys::Tab));
        key.setInitialized(true);
        hack::lateInitializeHacks();

        s_isInitialized = true;

        return true;
    }


};

class HackUpdater : public cocos2d::CCObject {
public:
    static HackUpdater* create() {
        auto ret = new HackUpdater();
        ret->autorelease();
        return ret;
    }

    void update(float dt) override {
        for (const auto& hack : hack::getUpdatedHacks())
            hack->update();

        keybinds::Manager::get()->update();
        gui::blur::update(dt);
    }
};

$on_mod(Loaded) {
    // Migrate appearance settings; all versions now use the ImGui menu.
    config::load();
    gxlx::migrateSettings();
    ImGuiCocos::get().setForceLegacy(config::get<bool>("gxlx.legacy-render", false));

    // Load language files
    i18n::init();

    // Initialize the hacks.
    hack::initializeHacks();

    // Load keybinds
    keybinds::Manager::get()->init();

    gui::ThemeManager::get();

    // Add bitmap fonts to texture search path
    auto bmfontPath = geode::Mod::get()->getConfigDir() / "bmfonts";
    std::error_code ec;
    std::filesystem::create_directories(bmfontPath / GEODE_MOD_ID, ec);
    if (ec) {
        geode::log::warn("Failed to create bitmap fonts directory {}: {}", bmfontPath, ec.message());
    }

    utils::get<cocos2d::CCFileUtils>()->addSearchPath(geode::utils::string::pathToString(bmfontPath).c_str());
    geode::log::info("Added bitmap fonts to search path: {}", bmfontPath);

    // Add remaining interface options (no font or theme customization)
    {
        using namespace gui;
        auto tab = MenuTab::find("tab.interface");
        // GxLx / Slaughterhouse is the only theme; the selection UI was removed.
        tab->addInputFloat("interface.ui-scale", "uiScale", 0.75f, 2.f, "x%.3f")
           ->callback([](float value) {
               ThemeManager::get()->setUIScale(value);
           })->disableSaving();
        config::setIfEmpty("interface.dpi-scaling", true);
        tab->addToggle("interface.dpi-scaling")
           ->setDescription();

        auto blurToggle = tab->addToggle("interface.enable-blur", "blurEnabled")
                             ->callback([](bool value) { ThemeManager::get()->setBlurEnabled(value); });
        blurToggle->addOptions([](auto opt) {
            opt->addInputFloat("interface.blur-speed", "blurSpeed", 0.f, 10.f, "%.3f s")
               ->callback([](float value) { ThemeManager::get()->setBlurSpeed(value); })
               ->disableSaving();
        });
        blurToggle->disableSaving();

        config::setIfEmpty<bool>("menu.animateWindows", true);
        config::setIfEmpty("menu.animationDuration", 0.3);
        config::setIfEmpty("menu.animationEasingType", animation::Easing::Quadratic);
        config::setIfEmpty("menu.animationEasingMode", animation::EasingMode::EaseInOut);
        auto animateToggle = tab->addToggle("menu.animateWindows")->setDescription();
        animateToggle->addOptions([](auto opt) {
            opt->addInputFloat("menu.animationDuration", 0.f, 10.f, "%.3f s");
            opt->addCombo("menu.animationEasingType", {
                i18n::get_("menu.animationEasingType.0"),
                i18n::get_("menu.animationEasingType.1"),
                i18n::get_("menu.animationEasingType.2"),
                i18n::get_("menu.animationEasingType.3"),
                i18n::get_("menu.animationEasingType.4"),
                i18n::get_("menu.animationEasingType.5"),
                i18n::get_("menu.animationEasingType.6"),
                i18n::get_("menu.animationEasingType.7"),
                i18n::get_("menu.animationEasingType.8"),
                i18n::get_("menu.animationEasingType.9"),
                i18n::get_("menu.animationEasingType.10"),
            }, 2);
            opt->addCombo("menu.animationEasingMode", {
                i18n::get_("menu.animationEasingMode.0"),
                i18n::get_("menu.animationEasingMode.1"),
                i18n::get_("menu.animationEasingMode.2"),
            }, 2);
        });
        animateToggle->setFlags(ComponentFlags::OnlyTabbed);

        config::setIfEmpty<bool>("menu.horizontallyCenter", true);
        tab->addToggle("menu.horizontallyCenter")->setFlags(ComponentFlags::OnlyTabbed);

    #ifdef ECLIPSE_USE_FLOATING_BUTTON

        config::setIfEmpty<float>("float-btn.max-opacity", 1.f);
        config::setIfEmpty<float>("float-btn.min-opacity", 0.5f);
        config::setIfEmpty<bool>("float-btn.show-in-level", false);
        config::setIfEmpty<bool>("float-btn.show-in-editor", true);
        config::setIfEmpty<float>("float-btn.scale", 0.25f);
        tab->addLabel("float-btn.title")->setFlags(ComponentFlags::DisableImGui);
        tab->addInputFloat("float-btn.max-opacity", 0.1f, 1.f)->setFlags(ComponentFlags::DisableImGui);
        tab->addInputFloat("float-btn.min-opacity", 0.1f, 1.f)->setFlags(ComponentFlags::DisableImGui);
        tab->addToggle("float-btn.show-in-level")->setFlags(ComponentFlags::DisableImGui);
        tab->addToggle("float-btn.show-in-editor")->setFlags(ComponentFlags::DisableImGui);
        tab->addInputFloat("float-btn.scale", 0.15f, 1.f)->setFlags(ComponentFlags::DisableImGui);

    #endif

        auto languageCombo = tab->addCombo(
            "interface.language", "language.index",
            i18n::getAvailableLanguages(), i18n::getLanguageIndex()
        );
        languageCombo->callback([languageCombo](int value) {
            i18n::setLanguage(i18n::fetchAvailableLanguages()[value].code);
            config::set("language", i18n::getCurrentLanguage());
            languageCombo->setItems(i18n::getAvailableLanguages());
            ImGuiCocos::get().reload();
        })->disableSaving();

        auto autoFocus = config::get<bool>("interface.search-auto-focus", false);
        auto searchInput = tab->addInputText("interface.search", "search");
        searchInput->callback([](std::string input) {
            static bool hasSearched = false;

            if (input.empty()) {
                if (hasSearched) {
                    for (auto& tab : Engine::get().getTabs()) {
                        tab.setSearchedFor(false);

                        for (auto& component : tab.getComponents())
                            component->removeFlag(ComponentFlags::SearchedFor);
                    }

                    hasSearched = false;
                }
            } else {
                hasSearched = true;

                for (auto& tab : Engine::get().getTabs()) {
                    bool hasFoundComponent = false;

                    for (auto& component : tab.getComponents()) {
                        if (utils::matchesStringFuzzy(i18n::get(component->getTitle()), input)) {
                            component->addFlag(ComponentFlags::SearchedFor);
                            hasFoundComponent = true;
                        } else component->removeFlag(ComponentFlags::SearchedFor);
                    }

                    tab.setSearchedFor(hasFoundComponent);
                }
            }
        })->disableSaving()
        ->setFlags(
            autoFocus ? ComponentFlags::StartWithKeyboardFocus
                      : ComponentFlags::None
        );
        tab->addToggle("interface.search-auto-focus")
            ->setDescription()->callback([searchInput](bool value) {
                searchInput->setFlags(
                    value ? ComponentFlags::StartWithKeyboardFocus
                          : ComponentFlags::None
                );
            });
    }

    // Schedule hack updates
    cocos2d::CCScheduler::get()->scheduleSelector(
        schedule_selector(HackUpdater::update),
        HackUpdater::create(), 0.f, false
    );


}
