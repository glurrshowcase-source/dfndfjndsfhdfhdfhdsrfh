// A visual cover only: GD and Geode retain their normal loading lifecycle.
#include "branding.hpp"
#include <Geode/Geode.hpp>
#include <Geode/modify/LoadingLayer.hpp>
#include <algorithm>
#include <cmath>

using namespace geode::prelude;

class $modify(GxLxLoadingLayer, LoadingLayer) {
    struct Fields {
        CCLayerColor* cover = nullptr;
        CCSprite* logo = nullptr;
        CCLayerColor* track = nullptr;
        CCLayerGradient* fill = nullptr;
        CCLayerColor* shine = nullptr;
        float progress = 0;
    };

    bool init(bool refresh) {
        if (!LoadingLayer::init(refresh)) return false;
        auto* f = m_fields.self();
        auto size = CCDirector::get()->getWinSize();
        f->cover = CCLayerColor::create({0, 0, 0, 255}, size.width, size.height);
        f->cover->setID("gxlx-loading-cover");
        // The original nodes remain alive for Geode's progress and resource hooks.
        addChild(f->cover, 10000);
        auto path = utils::string::pathToString(gxlx::resource("gxlx-logo.png"));
        f->logo = CCSprite::create(path.c_str());
        if (f->logo) f->cover->addChild(f->logo);
        f->track = CCLayerColor::create({40, 4, 10, 255});
        f->fill = CCLayerGradient::create({119, 0, 22, 255}, {255, 32, 55, 255}, {1, 0});
        f->shine = CCLayerColor::create({255, 129, 142, 255});
        f->cover->addChild(f->track);
        f->cover->addChild(f->fill);
        f->cover->addChild(f->shine);
        updateGxLx(0.f);
        schedule(schedule_selector(GxLxLoadingLayer::updateGxLx));
        return true;
    }

    void updateGxLx(float) {
        auto* f = m_fields.self();
        if (!f->cover) return;
        auto size = CCDirector::get()->getWinSize();
        f->cover->setContentSize(size);
        if (f->logo) {
            float extent = std::min(size.height * .48f, size.width * .38f);
            f->logo->setScale(extent / f->logo->getContentSize().height);
            f->logo->setPosition({size.width*.5f, size.height*.56f});
        }
        // The native bar already includes Geode's mod/resource loading stages.
        if (m_sliderBar && m_sliderGrooveXPos > 0.f) {
            float value = m_sliderBar->getTextureRect().size.width / m_sliderGrooveXPos;
            if (std::isfinite(value)) f->progress = std::max(f->progress, std::clamp(value, 0.f, 1.f));
        }
        const float width = std::min(size.width*.52f, 320.f);
        const float left = (size.width-width)*.5f;
        const float bottom = size.height*.23f;
        f->track->setContentSize({width+4, 10});
        f->track->setPosition({left-2, bottom-2});
        f->fill->setContentSize({width*f->progress, 6});
        f->fill->setPosition({left, bottom});
        f->shine->setContentSize({width*f->progress, 1});
        f->shine->setPosition({left, bottom+5});
    }
};
