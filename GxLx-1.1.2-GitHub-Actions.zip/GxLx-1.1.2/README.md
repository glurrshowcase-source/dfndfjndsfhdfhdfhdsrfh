> **GxLx 1.1.2 — aktualizacja kodu źródłowego.** Ten pakiet nie zawiera skompilowanego `.geode` 1.1.2. Zobacz [ZMIANY-1.1.2.md](ZMIANY-1.1.2.md).

# GxLx 1.1.1 — Windows, GD 2.2081

Czerwono-czarne menu Geode z gradientami, motywami **GRIEF** i **SLAUGHTERHOUSE**.
Jest to zmodyfikowany Eclipse Menu 1.9.4 (EPL-2.0), z dodatkowymi funkcjami GxLx.
Nie jest to pełna kopia Mega Hack 9: szczegółowe różnice są w `ZGODNOSC.md`.

## Instalacja

1. Używaj Geometry Dash **2.2081**, Windows 10/11 x64 i **Geode 5.11.2**.
   Oficjalne wydanie: https://github.com/geode-sdk/geode/releases/tag/v5.11.2
2. Zamknij grę. Umieść **gxlx.menu.geode** w folderze **Geometry Dash/geode/mods/**.
3. Uruchom GD. Domyślnie **Tab** otwiera i zamyka menu. Aktualizacja zachowuje Twój zapisany skrót, np. **Num +**. Zmienisz go w **Geode → GxLx → zębatka → Menu Keybind**; zmiana zapisuje się od razu.
4. W **Interface → Theme** wybierz `GxLx / GRIEF` lub `GxLx / SLAUGHTERHOUSE`.
   GRIEF jest domyślnym motywem. Skala interfejsu i język są w Interface.

GxLx ma własny identyfikator `gxlx.menu` i osobne ustawienia. Eclipse Menu jest oznaczone
jako niekompatybilne, ponieważ oba mody instalowałyby te same hooki. Na pierwszy test
wyłącz inne duże mod menu, w tym Mega Hack / QOLMod, aby uniknąć ich nakładania.
Odinstalowanie: zamknij grę i usuń `gxlx.menu.geode` z `geode/mods`.

## Zmiany w 1.1.1

**Menu korzysta wyłącznie z ImGui.** Alternatywny renderer Cocos oraz jego panele i okna opcji zostały usunięte z kodu i kompilacji. Poprzedni wybór Cocos w konfiguracji, profilu lub motywie nie może go przywrócić. Po aktualizacji nie trzeba ręcznie edytować plików. Dotychczasowy keybind i opcje gameplay zostają zachowane.

Ustawienia Geode nadal zawierają tylko Menu Keybind. Natywne kontrolki tego ustawienia, ekran ładowania i etykiety gry korzystają z API GD/Geode — nie są alternatywnym stylem menu.

## Zmiany w 1.1.0

- Ustawienia Geode zawierają tylko **Menu Keybind**. Aktualizacja zachowuje dotychczasowy skrót. Od wersji 1.1.1 dostępne jest wyłącznie ImGui.
- Panele obracają się i wlatują na miejsce, z krótkim opóźnieniem kolejnych paneli. Ponowne naciśnięcie skrótu odwraca bieżącą animację. Przytrzymanie klawisza nie powtarza otwierania.
- Animacje obejmują układy ImGui: Tabbed, Panel i Sidebar.
- Na dole otwartego menu widnieją **GXLX menu** i przesłane czerwone logo. Stopka znika od razu po rozpoczęciu zamykania; nie jest etykietą rozgrywki.
- Logo z przesłanego PNG jest też ikoną moda w Geode. Dostarczony MP3 (1,872 s) odtwarza się przy każdym naciśnięciu skrótu otwierania/zamykania. Korzysta z głośności efektów GD; ponowne naciśnięcie restartuje dźwięk.
- Podczas standardowego ładowania GD pojawia się czarne tło, logo pośrodku i czerwony pasek. Pasek odczytuje rzeczywisty postęp natywnego paska, w tym etapy Geode. Ładowanie zasobów i modów nadal przebiega normalnie. To działa od uruchomienia hooka LoadingLayer; etap przed załadowaniem Geode nie może być podmieniony przez ten mod.

Aktualizacja: po zamknięciu GD zastąp poprzedni **gxlx.menu.geode** nowym plikiem. Nie usuwaj katalogu ustawień GxLx. Po ponownym uruchomieniu Geode odczyta nowe logo i zasoby.

## Co jest w środku

- Funkcje bazy Eclipse: noclip z licznikiem kolizji, FPS/TPS bypass, speedhack,
  replay bot, frame stepper, StartPos Switcher, Smart StartPos, hitboxy,
  Show Trajectory, odblokowania, narzędzia edytora, etykiety i keybindy.
- Dodatki GxLx: Force Don't Enter/Fade, ukrywanie prób i pauzy, No New Best,
  No Rotation, No Pulse, No Wave Pulse/Trail, No Orb Ring, Freeze Player,
  No Solids/Spikes/Hitbox, Everything Hurts i Force Visibility.
- Osobne efekty kolorów P1/P2, rainbow lub kolor stały dla ikon, glow, smug,
  wave i cząsteczek, losowanie ikon, Same Dual Colour i Inversed Trail.
- Kontrola okna, Smooth Fix, limit FPS w tle, Mute on Unfocus,
  zapis PNG, priorytet wątku, Auto Deafen przez skrót klawiaturowy.
- Dokładne pozycjonowanie zaznaczenia w edytorze, skalowanie, obrót, zoom i Z-order.
  Operacje na zaznaczeniu dodają standardowy krok Undo.

Prawy przycisk myszy na obsługiwanej opcji pozwala przypisać keybind.
Strzałki obok opcji otwierają ustawienia szczegółowe. Konfiguracja i motyw są
zapisywane przy zamykaniu menu. Funkcje zapobiegające zapisowi wyników są
w **Universal → Auto Safe Mode / Safe Mode**. Auto Safe Mode jest domyślnie włączone;
nie stanowi certyfikatu zgodności z regulaminem żadnej listy demonów.

Nagrywanie wideo wymaga opcjonalnego moda **FFmpeg API**; replay bot jest osobną
funkcją i nie potrzebuje FFmpeg. Replay format GxLx/Eclipse nie oznacza zgodności
z każdym formatem makr MH9. Auto Deafen wymaga ustawienia tego samego globalnego
skrótu w Discordzie: domyślnie **F13**, kod Windows **124**. Mod nie odczytuje stanu
wyciszenia Discorda, więc ręczne przełączanie podczas aktywnego Auto Deafen może
rozsynchronizować przełączanie. Zrzut PNG trafia do katalogu danych GxLx otwieranego
przez **Shortcuts → Save Folder** i obejmuje scenę gry, bez nakładki ImGui.

## Co zostało sprawdzone

- Kompilacja Release dla Windows x64 i linkowanie z oficjalnym **Geode.lib 5.11.2**.
- Pakowanie zasobów i wygenerowanie prawdziwego moda `.geode` przez Geode CLI.
- Zawartość archiwum, metadata, plik PE x64 i zależności importów.
- Render motywu z tym samym kodem ImGui użytym w modzie, oględziny obrazu.

**Nie wykonano testu rozgrywki na uruchomionym GD w Windows.** To kompilacja
przeznaczona do pierwszego testu, a nie potwierdzenie bezbłędnego działania
wszystkich hooków i ich kombinacji. `GxLx-preview.png` jest podglądem motywu
z przykładowymi stanami kontrolek; nie jest zrzutem działającej gry. Tak samo `GxLx-animation.gif` pokazuje kod transformacji ImGui, a nie test w GD. Audio i ekranu ładowania nie sprawdzono na uruchomionym Windows/GD.

## Źródła i budowanie

Pełny zmodyfikowany kod znajduje się w folderze `source/GxLx` w paczce dystrybucyjnej.
Licencja: `LICENSE.md`, autorstwo i informacje o forku: `NOTICE-GXLX.md`, oryginalny
opis i pełne podziękowania: `README-UPSTREAM.md`.

Wymagane: Git, CMake >=3.21, Ninja, Geode CLI 3.9+, SDK 5.11.2 oraz kompilator
zgodny z ABI MSVC (użyto Clang 19). Na Windows uruchom terminal deweloperski VS
z zainstalowanym Clang/Windows SDK. Skrypt `build-windows.ps1` buduje źródła,
nie instaluje ich do gry i niczego nie publikuje. Potrzebuje skonfigurowanego
Geode CLI z profilem Windows oraz `GEODE_SDK` wskazującego SDK **5.11.2**.

Bindings są przypięte do `3e65294e5b68f0124cde08505b9ecbeb2e3d990b` (GD 2.2081).
Buduj codegen z tego samego źródła: najnowszy codegen Geode 6 generuje inne nagłówki.
Biblioteki są przypięte w `cmake/IncludeLibs.cmake`, tłumaczenia są dołączone lokalnie.
