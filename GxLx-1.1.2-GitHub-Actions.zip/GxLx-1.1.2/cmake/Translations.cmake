# Bundled snapshot keeps this build reproducible and preserves GxLx additions.
target_compile_definitions(${PROJECT_NAME} PRIVATE ECLIPSE_TRANSLATION_TIMESTAMP=9999999999)
