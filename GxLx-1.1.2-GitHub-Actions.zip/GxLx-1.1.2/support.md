# GxLx

This is an unofficial customized fork. Report GxLx-specific issues to the person who supplied this build; include geode/logs and geode/crashlogs.

Original project credits and support information are preserved in README-UPSTREAM.md and SUPPORT-UPSTREAM.md.
