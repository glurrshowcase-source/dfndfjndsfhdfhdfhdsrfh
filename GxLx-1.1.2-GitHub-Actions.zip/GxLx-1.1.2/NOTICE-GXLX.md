# GxLx — modified Eclipse Menu

GxLx 1.1.1 is a customized fork of Eclipse Menu 1.9.4, not an official
Eclipse Menu or Mega Hack release. The upstream authors are Eclipse Team,
ninXout, prevter, maxnu, Firee, SpaghettDev and the contributors credited
in README-UPSTREAM.md. Their existing notices and license are preserved.

Upstream: https://git.eclipse.menu/EclipseMenu/EclipseMenu
Base commit: d45f2f40fa7ec2492ad399027ca7151e5ee09d8f

Changes dated 2026-11-08: GxLx identity, Windows 2.2081 / Geode 5.11.2
target, red/black gradient themes and native rendering, build fixes,
additional controls, bundled translations, and Polish documentation.
Version 1.1.0 adds animated transitions, hotkey-only Geode settings, menu
footer, user-supplied logo/audio, and a visual LoadingLayer cover.
The user supplied the GxLx logo PNG and MP3 for this build. Their inclusion
does not change the license of the upstream code or dependency assets.

The complete modified source code is included in this distribution under
the Eclipse Public License 2.0 (LICENSE.md). Dependencies retain their own
licenses. GxLx does not contain Mega Hack source code or its paid assets.

Version 1.1.1 removes the alternative Cocos menu renderer and its panels.
ImGui is the only menu renderer; shared native Geode controls remain.
