# GxLx 1.1.7

A customized Geode mod menu for Windows.

**New:** 10-click video easter egg, secret G X L X level shortcut, full-screen custom red loading screen, animated fiery progress bar and a short intro sound that stops when loading ends, compact windows and menu search.

**Build:** Geode SDK 5.11.2, GD 2.2081 on Windows x64; GitHub Actions workflow included.

**YouTube:** https://www.youtube.com/@DJakDoki

The inherited modified code remains licensed EPL-2.0 with upstream author notices. Original GxLx-owned material is governed by the separate GxLx original works license where applicable.

See BUILD-GXLX-1.1.7.md for instructions and details.
