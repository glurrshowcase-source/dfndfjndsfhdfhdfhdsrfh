
## v1.1.7 (2026-11-09)
- Replaced 1.1.6 logo loading cover with supplied full-screen GxLx / GD fire artwork.
- Replaced thin neon laser with dynamically clipped orange-yellow fire bar, using submitted bar artwork and a bright moving tip.
- Replaced intro track with supplied `loading-sound.mp3` (12.67 seconds); prevents sound carrying into main menu.
- Retains GD's actual loader progress and all previously built-in menu features.
