# GxLx v1.1.7

## Build

Upload the provided `GxLx-1.1.7-GitHub-Actions.zip` to the root of your connected GitHub repository. It contains exactly one folder `GxLx-1.1.7` with CMakeLists.txt, mod.json and resources.

The repository workflow `.github/workflows/build.yml` should extract this ZIP and use `geode-sdk/build-geode-mod@main` with Geode SDK 5.11.2 and Win64, using project path `extracted/GxLx-1.1.7`.

## Updated loading cover

- `resources/GxLx/loading-screen.png` — submitted full-screen artwork.
- `resources/GxLx/loading-bar-frame.png` and `loading-bar-outline.png` — unfilled neon bar and highlight border derived from submitted loading_bar.png.
- `resources/GxLx/loading-bar-fire.png` and `loading-bar-head.png` — animated fill and fiery head derived from bar.
- `resources/GxLx/loading-sound.mp3` — submitted audio, played as loading-layer-scoped effect, stopped at 100% or exit.

Previous Easter eggs, UI search and modifications remain unchanged. Upstream EPL-2.0 notices are preserved.

## Status

Source changes are prepared and asset files are validated. The .geode binary must be compiled and the loading screen/runtime audio verified in Geometry Dash 2.2081 on Windows.
