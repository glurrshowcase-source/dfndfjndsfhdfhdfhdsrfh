// GxLx 1.1.7: full-screen user-provided artwork, fiery progress bar, and scoped intro audio.
// The underlying Geometry Dash loading progress remains authoritative; no fake timer.
#include "branding.hpp"
#include <Geode/Geode.hpp>
#include <Geode/modify/LoadingLayer.hpp>
#include <algorithm>
#include <cmath>
#include <filesystem>

using namespace geode::prelude;

class $modify(GxLxLoadingLayer, LoadingLayer) {
    struct Fields {
        CCLayerColor* cover = nullptr;
        CCSprite* background = nullptr;
        CCSprite* barTrack = nullptr;
        CCSprite* barFire = nullptr;
        CCSprite* barHead = nullptr;
        CCSprite* barOutline = nullptr;
        CCLabelTTF* percent = nullptr;
        bool loadingDone = false;
        bool musicStarted = false;
        int musicChannel = -1;
        float progress = 0.f;
        float elapsed = 0.f;
    };

    void stopGxLxLoadingSound() {
        auto* f = m_fields.self();
        if (!f->musicStarted || f->musicChannel < 0) return;
        // Stop only our own effect: other GD/game sounds must not be interrupted.
        auto* engine = FMODAudioEngine::get();
        auto soundPath = utils::string::pathToString(gxlx::resource("loading-sound.mp3"));
        if (auto it = engine->m_channelIDToSoundPath.find(f->musicChannel);
            it != engine->m_channelIDToSoundPath.end() && it->second == soundPath) {
            engine->stopChannel(f->musicChannel);
        }
        f->musicChannel = -1;
        f->musicStarted = false;
    }

    bool init(bool refresh) {
        if (!LoadingLayer::init(refresh)) return false;
        auto* f = m_fields.self();
        auto size = CCDirector::get()->getWinSize();

        f->cover = CCLayerColor::create({0, 0, 0, 255}, size.width, size.height);
        f->cover->setID("gxlx-loading-cover");
        addChild(f->cover, 10000); // Hide the original scene without interrupting initialization.
        const auto makeSprite = [f](char const* name, int order) -> CCSprite* {
            auto path = utils::string::pathToString(gxlx::resource(name));
            auto* sprite = CCSprite::create(path.c_str());
            if (sprite) f->cover->addChild(sprite, order);
            return sprite;
        };
        f->background = makeSprite("loading-screen.png", 0);
        // Two copies of the supplied bar: the track is below the flames, and
        // the original glowing border is above them, so the indicator is never pre-filled.
        f->barTrack = makeSprite("loading-bar-frame.png", 5);
        f->barFire = makeSprite("loading-bar-fire.png", 6);
        f->barHead = makeSprite("loading-bar-head.png", 7);
        f->barOutline = makeSprite("loading-bar-outline.png", 8);
        if (f->barFire) f->barFire->setAnchorPoint({0.f, 0.5f});
        if (f->barHead) f->barHead->setVisible(false);
        if (f->barFire) f->barFire->setVisible(false);

        f->percent = CCLabelTTF::create("0%", "Arial", 14.f);
        if (f->percent) {
            f->percent->setColor({255, 214, 135});
            f->cover->addChild(f->percent, 9);
        }
        updateGxLx(0.f);
        schedule(schedule_selector(GxLxLoadingLayer::updateGxLx));
        return true;
    }

    void onExit() override {
        auto* f = m_fields.self();
        f->loadingDone = true;
        stopGxLxLoadingSound();
        unschedule(schedule_selector(GxLxLoadingLayer::updateGxLx));
        LoadingLayer::onExit();
    }

    void updateGxLx(float dt) {
        auto* f = m_fields.self();
        if (!f->cover) return;
        f->elapsed += std::max(0.f, dt);
        const auto size = CCDirector::get()->getWinSize();
        f->cover->setContentSize(size);
        // Cover the entire GD viewport, cropping at the edges on non-16:9 displays.
        if (f->background) {
            const auto imageSize = f->background->getContentSize();
            if (imageSize.width > 0 && imageSize.height > 0) {
                const float scale = std::max(size.width / imageSize.width,
                                             size.height / imageSize.height);
                f->background->setScale(scale);
                f->background->setPosition({size.width * 0.5f, size.height * 0.5f});
            }
        }

        // Read the native GD loading bar. Never substitute time-based progress.
        if (m_sliderBar && m_sliderGrooveXPos > 0.f) {
            const float ratio = m_sliderBar->getTextureRect().size.width / m_sliderGrooveXPos;
            if (std::isfinite(ratio)) {
                f->progress = std::max(f->progress, std::clamp(ratio, 0.f, 1.f));
            }
        }
        if (f->progress >= 0.999f && !f->loadingDone) {
            f->loadingDone = true;
            stopGxLxLoadingSound(); // Silence by the time the game reaches the main menu.
        }
        if (!f->loadingDone && !f->musicStarted && f->progress > 0.01f) {
            const auto intro = gxlx::resource("loading-sound.mp3");
            if (std::filesystem::exists(intro)) {
                const int channel = FMODAudioEngine::get()->playEffect(utils::string::pathToString(intro));
                if (channel >= 0) {
                    f->musicChannel = channel;
                    f->musicStarted = true;
                }
            }
        }

        // Image geometry is measured in original uploaded bar pixels.
        // Sprite crop: original x=50..1998 and y=230..466 (1948 x 236).
        const float scale = size.width * 0.83f / 1948.f;
        const float centerX = size.width * 0.5f;
        const float centerY = size.height * 0.19f;
        const float barLeft = centerX - 1948.f * scale * .5f;
        const float fireLeft = barLeft + (138.f - 50.f) * scale;
        const float fireWidth = 1770.f;

        for (auto* sprite : {f->barTrack, f->barOutline}) {
            if (!sprite) continue;
            sprite->setScale(scale);
            sprite->setPosition({centerX, centerY});
        }
        if (f->barFire) {
            f->barFire->setScale(scale);
            f->barFire->setPosition({fireLeft, centerY});
            const bool show = f->progress > .002f;
            f->barFire->setVisible(show);
            if (show) {
                f->barFire->setTextureRect(CCRect(0.f, 0.f,
                    std::max(1.f, fireWidth * f->progress), 86.f));
            }
        }
        if (f->barHead) {
            const bool show = f->progress > .002f && f->progress < .999f;
            f->barHead->setVisible(show);
            if (show) {
                f->barHead->setScale(scale);
                f->barHead->setPosition({fireLeft + fireWidth * f->progress * scale, centerY});
                const float pulse = 0.5f + 0.5f * std::sin(f->elapsed * 8.f);
                f->barHead->setOpacity(static_cast<unsigned char>(200.f + 55.f * pulse));
            }
        }
        if (f->percent) {
            f->percent->setString(fmt::format("{}%", std::clamp(static_cast<int>(f->progress * 100.f), 0, 100)).c_str());
            f->percent->setPosition({centerX, centerY - 118.f * scale - 8.f});
        }
    }
};
