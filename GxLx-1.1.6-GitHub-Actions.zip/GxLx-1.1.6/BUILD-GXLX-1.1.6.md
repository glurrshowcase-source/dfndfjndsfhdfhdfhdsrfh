# GxLx 1.1.6 — Windows build

This revision uses the user-supplied red GxLx wordmark on the startup screen, a narrow traveling laser linked to actual loading progress, and automatic shutdown of sevvend.mp3 when loading reaches 100% or the loading layer exits.

Upload this archive, without unpacking, as `GxLx-1.1.6-GitHub-Actions.zip` to the root of the connected GitHub repository. The workflow `.github/workflows/build.yml` is configured for Geode SDK 5.11.2 on Windows x64 and publishes an artifact named `GxLx-1.1.6-Windows`.

The zip contains a top-level directory `GxLx-1.1.6`. Compilation and gameplay behavior have not been verified for this revision.
