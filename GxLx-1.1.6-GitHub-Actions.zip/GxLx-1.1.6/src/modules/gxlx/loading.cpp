// GxLx red neon loading cover, based on native GD progress to avoid fake progress values.
#include "branding.hpp"
#include <Geode/Geode.hpp>
#include <Geode/modify/LoadingLayer.hpp>
#include <algorithm>
#include <cmath>
#include <filesystem>

using namespace geode::prelude;

class $modify(GxLxLoadingLayer, LoadingLayer) {
    struct Fields {
        CCLayerColor* cover = nullptr;
        CCSprite* logo = nullptr;
        CCLayerColor* backGlow = nullptr;
        CCLayerColor* outerGlow = nullptr;
        CCLayerColor* frame = nullptr;
        CCLayerColor* track = nullptr;
        CCLayerGradient* fill = nullptr;
        CCLayerColor* fillGlow = nullptr;
        CCLayerColor* shine = nullptr;
        CCLayerColor* laserHeadGlow = nullptr;
        CCLayerColor* laserHead = nullptr;
        bool loadingDone = false;
        float elapsed = 0.f;
        CCLabelTTF* percent = nullptr;
        float progress = 0;
        bool musicStarted = false;
        int musicChannel = -1;
    };

    bool init(bool refresh) {
        if (!LoadingLayer::init(refresh)) return false;
        auto* f = m_fields.self();
        auto size = CCDirector::get()->getWinSize();
        f->cover = CCLayerColor::create({0, 0, 0, 255}, size.width, size.height);
        f->cover->setID("gxlx-loading-cover");
        addChild(f->cover, 10000); // Hide normal loading content without disrupting GD/Geode hooks.
        auto logoPath = utils::string::pathToString(gxlx::resource("loading-logo.png"));
        f->logo = CCSprite::create(logoPath.c_str());
        if (f->logo) f->cover->addChild(f->logo);

        f->backGlow = CCLayerColor::create({215, 0, 22, 28});
        f->outerGlow = CCLayerColor::create({255, 6, 30, 64});
        f->frame = CCLayerColor::create({255, 36, 48, 200});
        f->track = CCLayerColor::create({76, 0, 10, 160});
        f->fill = CCLayerGradient::create({252, 14, 25, 255}, {255, 125, 130, 255}, {1, 0});
        f->fillGlow = CCLayerColor::create({255, 17, 40, 100});
        f->shine = CCLayerColor::create({255, 220, 220, 255});
        for (auto* node : {f->backGlow, f->outerGlow, f->frame, f->track, static_cast<CCLayerColor*>(f->fill), f->fillGlow, f->shine})
            f->cover->addChild(node);
        f->laserHeadGlow = CCLayerColor::create({255, 15, 38, 150});
        f->laserHead = CCLayerColor::create({255, 240, 241, 255});
        f->cover->addChild(f->laserHeadGlow);
        f->cover->addChild(f->laserHead);
        f->percent = CCLabelTTF::create("0%", "Arial", 17.f);
        if (f->percent) {
            f->percent->setColor({255, 37, 59});
            f->cover->addChild(f->percent);
        }
        updateGxLx(0.f);
        schedule(schedule_selector(GxLxLoadingLayer::updateGxLx));
        return true;
    }

    void onExit() override {
        auto* f = m_fields.self();
        f->loadingDone = true;
        if (f->musicStarted && f->musicChannel >= 0) {
            auto* engine = FMODAudioEngine::get();
            auto songPath = utils::string::pathToString(gxlx::resource("sevvend.mp3"));
            if (auto it = engine->m_channelIDToSoundPath.find(f->musicChannel);
                it != engine->m_channelIDToSoundPath.end() && it->second == songPath)
                engine->stopChannel(f->musicChannel);
            f->musicStarted = false;
            f->musicChannel = -1;
        }
        unschedule(schedule_selector(GxLxLoadingLayer::updateGxLx));
        LoadingLayer::onExit();
    }

    void updateGxLx(float dt) {
        auto* f = m_fields.self();
        if (!f->cover) return;
        f->elapsed += std::max(0.f, dt);
        auto size = CCDirector::get()->getWinSize();
        f->cover->setContentSize(size);
        if (f->logo) {
            auto content = f->logo->getContentSize();
            if (content.height > 0) {
                float scale = std::min(size.width * .94f / content.width, size.height * .60f / content.height);
                f->logo->setScale(scale);
                f->logo->setPosition({size.width * .5f, size.height * .565f});
            }
        }
        // The game/Geode slider is the only source of progress, never an independent timer.
        if (m_sliderBar && m_sliderGrooveXPos > 0.f) {
            float value = m_sliderBar->getTextureRect().size.width / m_sliderGrooveXPos;
            if (std::isfinite(value)) f->progress = std::max(f->progress, std::clamp(value, 0.f, 1.f));
        }
        if (f->progress >= .999f && !f->loadingDone) {
            f->loadingDone = true;
            if (f->musicStarted && f->musicChannel >= 0) {
                auto* engine = FMODAudioEngine::get();
                auto path = utils::string::pathToString(gxlx::resource("sevvend.mp3"));
                auto it = engine->m_channelIDToSoundPath.find(f->musicChannel);
                if (it != engine->m_channelIDToSoundPath.end() && it->second == path)
                    engine->stopChannel(f->musicChannel);
                f->musicChannel = -1;
                f->musicStarted = false;
            }
        }
        if (!f->loadingDone && !f->musicStarted && f->progress > .01f) {
            auto song = gxlx::resource("sevvend.mp3");
            if (std::filesystem::exists(song)) {
                f->musicStarted = true;
                f->musicChannel = FMODAudioEngine::get()->playEffect(utils::string::pathToString(song));
            }
        }
        // A thin laser sweeps horizontally below the full-width wordmark.
        const float width = size.width * .88f;
        const float left = (size.width - width) * .5f;
        const float bottom = size.height * .21f;
        const float beam = width * f->progress;
        f->backGlow->setContentSize({width + 26.f, 17.f});
        f->backGlow->setPosition({left - 13.f, bottom - 7.f});
        f->outerGlow->setContentSize({beam, 15.f});
        f->outerGlow->setPosition({left, bottom - 6.f});
        f->frame->setContentSize({beam, 4.f});
        f->frame->setPosition({left, bottom});
        f->track->setContentSize({width, 1.6f});
        f->track->setPosition({left, bottom + 1.f});
        f->fill->setContentSize({beam, 3.f});
        f->fill->setPosition({left, bottom});
        f->fillGlow->setContentSize({beam, 12.f});
        f->fillGlow->setPosition({left, bottom - 4.f});
        f->shine->setContentSize({beam, 1.f});
        f->shine->setPosition({left, bottom + 3.f});
        const bool headVisible = f->progress > .002f && f->progress < 1.f;
        f->laserHeadGlow->setVisible(headVisible);
        f->laserHead->setVisible(headVisible);
        if (headVisible) {
            const float tip = left + beam;
            f->laserHeadGlow->setContentSize({21.f, 22.f});
            f->laserHeadGlow->setPosition({tip - 10.f, bottom - 9.f});
            f->laserHead->setContentSize({3.f, 9.f});
            f->laserHead->setPosition({tip - 1.5f, bottom - 3.f});
            const float pulse = .5f + .5f * std::sin(f->elapsed * 9.f);
            f->laserHeadGlow->setOpacity(static_cast<unsigned char>(90.f + 90.f * pulse));
        }
        if (f->percent) {
            f->percent->setString(fmt::format("{}%", std::clamp(static_cast<int>(f->progress * 100.f), 0, 100)).c_str());
            f->percent->setPosition({size.width * .5f, bottom - 29.f});
        }
    }
};
