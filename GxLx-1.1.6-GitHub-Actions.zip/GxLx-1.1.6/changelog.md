# GxLx 1.1.6

- Wide red GxLx logo from the supplied artwork on the loading screen.
- A moving red laser underneath the wordmark replaces the rectangular loading bar.
- sevvend.mp3 stops on completion and on loading layer exit.

# GxLx 1.1.5
- Added 10-click movie easter egg, G X L X secret level shortcut, neon progress bar with music, compact menu windows and hack search.
- Media playback is currently Windows-only.

# GxLx 1.1.4 — 2026-11-08

- Rebranded internal namespaces, macros, UI wording, labels and visual assets to GxLx.
- Changed the main Geode developer and link to GxLx / @DJakDoki.
- Added a custom license for original GxLx works, while preserving the EPL-2.0 base-code license.
- Retained exact external dependency identifiers and required upstream legal notices.

## GxLx 1.1.3 — 2026-11-08

- Updated description, developer field and link.

## GxLx 1.1.2 — 2026-11-08

- Fixed default menu presentation and removed theme selection.
